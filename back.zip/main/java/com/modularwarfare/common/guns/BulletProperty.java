package com.modularwarfare.common.guns;

public class BulletProperty {
	
	/** Damage inflicted per bullet. Multiplied by the gun damage value. */
	public float bulletDamage = 1;
	
	public PotionEntry[] potionEffects;

}
