package com.modularwarfare.common.guns;

public class PotionEntry {
	
	public PotionEffectEnum potionEffect;
	public int duration = 0;
	public int level = 0;

}
