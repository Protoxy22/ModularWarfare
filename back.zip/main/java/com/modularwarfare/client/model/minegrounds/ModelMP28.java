package com.modularwarfare.client.model.minegrounds;

import com.modularwarfare.api.WeaponAnimation;
import com.modularwarfare.api.WeaponAnimations;
import com.modularwarfare.client.model.ModelGun;
import com.modularwarfare.client.tmt.ModelRendererTurbo;
import org.lwjgl.util.vector.Vector3f;

public class ModelMP28 extends ModelGun {

	int textureX = 256;
	int textureY = 256;

	public ModelMP28() {

		gunModel = new ModelRendererTurbo[1];

		gunModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		gunModel[0].addObj("guns/mp28/body");
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		ammoModel = new ModelRendererTurbo[1];

		ammoModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		ammoModel[0].addObj("guns/mp28/ammo");
		ammoModel[0].setRotationPoint(0F, 0F, 0F);
		ammoModel[0].setDefaultTexture("textures/mp28/mp28mag.png");

		slideModel = new ModelRendererTurbo[1];

		slideModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 1
		slideModel[0].addObj("guns/mp28/slide");
		slideModel[0].setRotationPoint(0F, 0F, 0F);

		leftArmPos = new Vector3f(0.2F, -0.52F, 0.02F);
		leftArmRot = new Vector3f(65.0F, 30.0F, -45.0F);
		leftArmReloadPos = new Vector3f(0.10F, -0.40F, 0.02F);
		leftArmReloadRot = new Vector3f(65.0F, 12.0F, -55.0F);

		rightArmPos = new Vector3f(0.15F, -0.58F, 0.0F);
		rightArmRot = new Vector3f(0.0F, 0.0F, -90.0F);
		rightArmReloadPos = new Vector3f(0.75F, -0.55F, 0.1F);
		rightArmReloadRot = new Vector3f(5.0F, 15.0F, -100.0F);

		rightArmChargePos = new Vector3f(0.47F, -0.39F, 0.14F);
		rightArmChargeRot = new Vector3f(0.0F, 0.0F, -90.0F);

		rightArmScale = new Vector3f(0.60F, 1.0F, 0.60F);
		leftArmScale = new Vector3f(0.60F, 1.0F, 0.60F);

		hasFlash = true;
		flashScale = 0.3F;
		this.muzzleFlashPointNormal = new Vector3f(1.5F, 1.3F, 1F);
		this.muzzleFlashPointScoping = new Vector3f(1.5F, 1.8F, 0.1F);

		rotateAimPosition = new Vector3f(0F, -0F, -0.2F);

		leftHandAmmo = true;

		fancyStance = true;
		sprintRotate = new Vector3f(-20.0F, 30.0F, -0.0F);
		sprintTranslate = new Vector3f(0.5F, -0.10F, -0.65F);

		this.thirdPersonOffset = new Vector3f(0F, -0.2F, 0F);
		translateAll = new Vector3f(0F, -1.15F, 0F);
		flipAll();
	}
}
