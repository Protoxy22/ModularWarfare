package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelkskPants
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelkskPants()
  {
    this.leftLegModel = new ModelRendererTurbo[3];
    this.leftLegModel[0] = new ModelRendererTurbo(this, 89, 33, this.textureX, this.textureY);
    this.leftLegModel[1] = new ModelRendererTurbo(this, 41, 97, this.textureX, this.textureY);
    this.leftLegModel[2] = new ModelRendererTurbo(this, 73, 81, this.textureX, this.textureY);
    
    this.leftLegModel[0].addShapeBox(-1.9F, 0.0F, -2.0F, 8, 22, 8, 0.0F, 0.1F, 0.1F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -11.9F, 0.1F, -3.9F, -11.9F, 0.1F, -3.9F, -11.9F, -3.9F, 0.1F, -11.9F, -3.9F);
    this.leftLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[1].addShapeBox(-2.0F, -1.0F, -3.0F, 5, 3, 6, 0.0F, 0.0F, 0.0F, -1.0F, -0.7F, 0.0F, -1.0F, -0.7F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F);
    this.leftLegModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[2].addShapeBox(1.5F, 5.0F, -2.0F, 1, 3, 3, 0.0F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F);
    this.leftLegModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel = new ModelRendererTurbo[3];
    this.rightLegModel[0] = new ModelRendererTurbo(this, 41, 41, this.textureX, this.textureY);
    this.rightLegModel[1] = new ModelRendererTurbo(this, 97, 17, this.textureX, this.textureY);
    this.rightLegModel[2] = new ModelRendererTurbo(this, 105, 73, this.textureX, this.textureY);
    
    this.rightLegModel[0].addShapeBox(-2.1F, 0.0F, -2.0F, 8, 22, 8, 0.0F, 0.1F, 0.1F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -11.9F, 0.1F, -3.9F, -11.9F, 0.1F, -3.9F, -11.9F, -3.9F, 0.1F, -11.9F, -3.9F);
    this.rightLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[1].addShapeBox(-3.0F, -1.0F, -3.0F, 5, 3, 6, 0.0F, -0.7F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, -0.7F, 0.0F, -1.0F, -0.5F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F);
    this.rightLegModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[2].addShapeBox(-2.5F, 5.0F, -2.0F, 1, 3, 3, 0.0F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F);
    this.rightLegModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
