package com.modularwarfare.client.model.minegrounds.attachments;

import com.modularwarfare.client.model.ModelAttachment;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelSMGSUPRESSOR extends ModelAttachment {

    int textureX = 16;
    int textureY = 16;

    public ModelSMGSUPRESSOR() {

        attachmentModel = new ModelRendererTurbo[1];

        attachmentModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
        attachmentModel[0].addObj("attachments/supressor");
        attachmentModel[0].setRotationPoint(0F, 0F, 0F);

        flipAll();
    }
}