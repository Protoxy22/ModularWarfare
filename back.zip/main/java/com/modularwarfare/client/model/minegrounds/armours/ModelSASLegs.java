package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelSASLegs
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelSASLegs()
  {
    this.leftLegModel = new ModelRendererTurbo[5];
    this.leftLegModel[0] = new ModelRendererTurbo(this, 25, 17, this.textureX, this.textureY);
    this.leftLegModel[1] = new ModelRendererTurbo(this, 89, 9, this.textureX, this.textureY);
    this.leftLegModel[2] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
    this.leftLegModel[3] = new ModelRendererTurbo(this, 17, 17, this.textureX, this.textureY);
    this.leftLegModel[4] = new ModelRendererTurbo(this, 105, 25, this.textureX, this.textureY);
    
    this.leftLegModel[0].addShapeBox(-2.0F, -0.1F, -2.0F, 4, 8, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.leftLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[1].addShapeBox(-1.5F, 4.5F, -2.3F, 3, 1, 1, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F);
    this.leftLegModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[2].addShapeBox(-1.5F, 2.5F, -2.3F, 3, 2, 1, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.leftLegModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[3].addShapeBox(-1.5F, 1.5F, -2.3F, 3, 1, 1, 0.0F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.leftLegModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftLegModel[4].addShapeBox(-2.0F, 3.0F, -2.0F, 4, 1, 4, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F);
    this.leftLegModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel = new ModelRendererTurbo[5];
    this.rightLegModel[0] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.rightLegModel[1] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    this.rightLegModel[2] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
    this.rightLegModel[3] = new ModelRendererTurbo(this, 113, 1, this.textureX, this.textureY);
    this.rightLegModel[4] = new ModelRendererTurbo(this, 73, 17, this.textureX, this.textureY);
    
    this.rightLegModel[0].addShapeBox(-2.0F, -0.1F, -2.0F, 4, 8, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.rightLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[1].addShapeBox(-1.5F, 2.5F, -2.3F, 3, 2, 1, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.rightLegModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[2].addShapeBox(-1.5F, 1.5F, -2.3F, 3, 1, 1, 0.0F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.rightLegModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[3].addShapeBox(-1.5F, 4.5F, -2.3F, 3, 1, 1, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F, -0.5F, -0.5F, 0.1F);
    this.rightLegModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel[4].addShapeBox(-2.0F, 3.0F, -2.0F, 4, 1, 4, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F);
    this.rightLegModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
