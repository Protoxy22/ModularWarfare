package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelPressVest
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelPressVest()
  {
    this.bodyModel = new ModelRendererTurbo[15];
    this.bodyModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 33, 1, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 65, 1, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 81, 1, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 113, 1, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 57, 9, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 73, 9, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 89, 9, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 105, 9, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 17, 17, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 105, 9, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, 11, 33, this.textureX, this.textureY);
    this.bodyModel[14] = new ModelRendererTurbo(this, -93, 84, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.0F, 8.0F, -2.0F, 8, 4, 4, 0.0F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.0F, 2.8F, -2.0F, 8, 5, 4, 0.0F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(-4.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(0.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -2.7F, 0.3F, 0.0F, -1.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(-2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -1.0F, 0.3F, 0.0F, -2.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(-2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, -1.5F, 0.7F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, -2.0F, 0.3F, 0.0F, -0.3F, 0.3F, 0.0F, -3.0F, 0.3F, 0.0F, -3.0F, 0.3F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(0.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -1.5F, 0.7F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, -0.3F, 0.3F, 0.0F, -2.0F, 0.3F, 0.0F, -3.0F, 0.3F, 0.0F, -3.0F, 0.3F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(-2.5F, 5.0F, -2.6F, 5, 5, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-3.0F, 2.5F, -2.5F, 6, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(-3.0F, 4.5F, -2.4F, 6, 6, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(-2.5F, 4.9F, -2.7F, 5, 2, 1, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-3.0F, 2.5F, 1.5F, 6, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(-2.5F, 2.75F, -2.51F, 100, 25, 1, 0.0F, 0.0F, 0.0F, 0.0F, -95.0F, 0.0F, 0.0F, -95.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -23.5F, 0.0F, -95.0F, -23.5F, 0.0F, -95.0F, -23.5F, 0.0F, 0.0F, -23.5F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[14].addShapeBox(-2.5F, 2.75F, 1.51F, 100, 25, 1, 0.0F, 0.0F, 0.0F, 0.0F, -95.0F, 0.0F, 0.0F, -95.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -23.5F, 0.0F, -95.0F, -23.5F, 0.0F, -95.0F, -23.5F, 0.0F, 0.0F, -23.5F, 0.0F);
    this.bodyModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
