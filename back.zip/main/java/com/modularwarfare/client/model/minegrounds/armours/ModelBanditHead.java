package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelBanditHead
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelBanditHead()
  {
    this.headModel = new ModelRendererTurbo[12];
    this.headModel[0] = new ModelRendererTurbo(this, 17, 33, this.textureX, this.textureY);
    this.headModel[1] = new ModelRendererTurbo(this, 57, 33, this.textureX, this.textureY);
    this.headModel[2] = new ModelRendererTurbo(this, 97, 33, this.textureX, this.textureY);
    this.headModel[3] = new ModelRendererTurbo(this, 1, 49, this.textureX, this.textureY);
    this.headModel[4] = new ModelRendererTurbo(this, 17, 17, this.textureX, this.textureY);
    this.headModel[5] = new ModelRendererTurbo(this, 81, 9, this.textureX, this.textureY);
    this.headModel[6] = new ModelRendererTurbo(this, 25, 49, this.textureX, this.textureY);
    this.headModel[7] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.headModel[8] = new ModelRendererTurbo(this, 121, 9, this.textureX, this.textureY);
    this.headModel[9] = new ModelRendererTurbo(this, 41, 73, this.textureX, this.textureY);
    this.headModel[10] = new ModelRendererTurbo(this, 57, 73, this.textureX, this.textureY);
    this.headModel[11] = new ModelRendererTurbo(this, 73, 73, this.textureX, this.textureY);
    
    this.headModel[0].addShapeBox(-4.0F, -8.0F, -4.0F, 8, 2, 8, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F);
    this.headModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[1].addShapeBox(-4.0F, -9.0F, -4.0F, 8, 1, 8, 0.0F, -2.0F, -0.5F, -2.0F, -2.0F, -0.5F, -2.0F, -2.0F, -0.5F, -2.0F, -2.0F, -0.5F, -2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[2].addShapeBox(-4.0F, -6.0F, -3.0F, 8, 4, 7, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F);
    this.headModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[3].addShapeBox(-4.0F, -2.0F, -3.0F, 8, 2, 7, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F);
    this.headModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[4].addShapeBox(-4.0F, -6.0F, -4.0F, 8, 1, 1, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F);
    this.headModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[5].addShapeBox(-3.0F, -3.0F, -4.0F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[6].addShapeBox(-4.0F, -2.0F, -4.0F, 8, 2, 1, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F);
    this.headModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[7].addShapeBox(-4.0F, -5.0F, -4.0F, 1, 3, 1, 0.0F, 0.2F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F);
    this.headModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[8].addShapeBox(3.0F, -5.0F, -4.0F, 1, 3, 1, 0.0F, 0.0F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[9].addShapeBox(0.0F, -3.0F, -4.0F, 3, 1, 1, 0.0F, 0.0F, -0.2F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[10].addShapeBox(0.0F, -5.0F, -4.0F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.headModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[11].addShapeBox(-3.0F, -5.0F, -4.0F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, -0.3F, 0.2F, 0.0F, -0.3F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
