package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelkskHat
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelkskHat()
  {
    this.headModel = new ModelRendererTurbo[9];
    this.headModel[0] = new ModelRendererTurbo(this, 1, 73, this.textureX, this.textureY);
    this.headModel[1] = new ModelRendererTurbo(this, 65, 65, this.textureX, this.textureY);
    this.headModel[2] = new ModelRendererTurbo(this, 41, 81, this.textureX, this.textureY);
    this.headModel[3] = new ModelRendererTurbo(this, 81, 81, this.textureX, this.textureY);
    this.headModel[4] = new ModelRendererTurbo(this, 1, 89, this.textureX, this.textureY);
    this.headModel[5] = new ModelRendererTurbo(this, 1, 105, this.textureX, this.textureY);
    this.headModel[6] = new ModelRendererTurbo(this, 65, 107, this.textureX, this.textureY);
    this.headModel[7] = new ModelRendererTurbo(this, 65, 107, this.textureX, this.textureY);
    this.headModel[8] = new ModelRendererTurbo(this, 65, 107, this.textureX, this.textureY);
    
    this.headModel[0].addShapeBox(-4.0F, -7.0F, -7.0F, 8, 1, 14, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.headModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[1].addShapeBox(4.0F, -7.0F, -7.0F, 3, 1, 14, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -1.2F, -2.0F, 0.0F, -1.2F, -2.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, 0.8F, -2.0F, 0.0F, 0.8F, -2.0F, 0.0F, -0.2F, 0.0F);
    this.headModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[2].addShapeBox(-4.0F, -8.5F, -4.0F, 8, 2, 8, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 0.0F, 0.5F, 0.5F, 0.0F, 0.5F, 0.5F, 0.0F, 0.5F, 0.5F, 0.0F, 0.5F);
    this.headModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[3].addShapeBox(-4.0F, -9.5F, -4.0F, 8, 1, 8, 0.0F, -1.0F, 0.0F, -1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[4].addShapeBox(-7.0F, -7.0F, -7.0F, 3, 1, 14, 0.0F, 0.0F, -1.2F, -2.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -1.2F, -2.0F, 0.0F, 0.8F, -2.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, 0.8F, -2.0F);
    this.headModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[5].addShapeBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F);
    this.headModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[6].addShapeBox(-8.5F, -6.0F, -3.0F, 5, 3, 6, 0.0F, -2.0F, 0.0F, -2.8F, -2.8F, 0.0F, -2.8F, -2.8F, 0.0F, -2.8F, -2.0F, 0.0F, -2.8F, -4.0F, 3.0F, -2.8F, -0.8F, 3.0F, -2.8F, -0.8F, 3.0F, -2.8F, -4.0F, 3.0F, -2.8F);
    this.headModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[7].addShapeBox(3.5F, -6.0F, -3.0F, 5, 3, 6, 0.0F, -2.8F, 0.0F, -2.8F, -2.0F, 0.0F, -2.8F, -2.0F, 0.0F, -2.8F, -2.8F, 0.0F, -2.8F, -0.8F, 3.0F, -2.8F, -4.0F, 3.0F, -2.8F, -4.0F, 3.0F, -2.8F, -0.8F, 3.0F, -2.8F);
    this.headModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[8].addShapeBox(-2.5F, -1.4F, -3.0F, 5, 3, 6, 0.0F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F, 2.0F, -1.4F, -2.8F);
    this.headModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
