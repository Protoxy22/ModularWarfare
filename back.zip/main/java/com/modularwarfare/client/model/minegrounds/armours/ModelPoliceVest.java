package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelPoliceVest
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelPoliceVest()
  {
    this.bodyModel = new ModelRendererTurbo[14];
    this.bodyModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 33, 1, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 65, 1, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 81, 1, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 113, 1, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 1, 9, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 17, 9, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 33, 9, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 65, 9, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 97, 9, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, -86, 50, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.0F, 10.8F, -2.0F, 8, 1, 4, 0.0F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.0F, 7.7F, -2.0F, 8, 1, 4, 0.0F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F, 0.4F, 0.0F, 0.4F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(0.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -1.5F, 0.7F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, -0.3F, 0.3F, 0.0F, -2.0F, 0.3F, 0.0F, -3.0F, 0.3F, 0.0F, -3.0F, 0.3F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(-2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, -1.5F, 0.7F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, -2.0F, 0.3F, 0.0F, -0.3F, 0.3F, 0.0F, -3.0F, 0.3F, 0.0F, -3.0F, 0.3F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(-2.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -1.0F, 0.3F, 0.0F, -2.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(0.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, -2.7F, 0.3F, 0.0F, -1.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(-4.0F, -0.2F, -2.0F, 2, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(-4.0F, 2.8F, -2.0F, 8, 5, 4, 0.0F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-4.0F, 8.0F, -2.0F, 8, 4, 4, 0.0F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(-3.5F, -0.3F, -2.0F, 2, 8, 4, 0.0F, 0.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(1.5F, -0.3F, -2.0F, 2, 8, 4, 0.0F, -1.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, -1.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-2.5F, 4.0F, 1.5F, 5, 3, 1, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(-2.25F, 4.5F, 1.51F, 100, 37, 1, 0.0F, 0.0F, 0.0F, 0.0F, -95.5F, 0.0F, 0.0F, -95.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -35.0F, 0.0F, -95.5F, -35.0F, 0.0F, -95.5F, -35.0F, 0.0F, 0.0F, -35.0F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
