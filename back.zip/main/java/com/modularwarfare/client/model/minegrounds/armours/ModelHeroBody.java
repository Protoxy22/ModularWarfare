package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelHeroBody
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelHeroBody()
  {
    this.bodyModel = new ModelRendererTurbo[53];
    this.bodyModel[0] = new ModelRendererTurbo(this, 89, 17, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 25, 33, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 1, 41, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 25, 49, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 57, 49, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 81, 49, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 81, 9, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 41, 25, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 65, 25, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 17, 33, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 73, 33, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 97, 49, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, 113, 33, this.textureX, this.textureY);
    this.bodyModel[14] = new ModelRendererTurbo(this, 1, 57, this.textureX, this.textureY);
    this.bodyModel[15] = new ModelRendererTurbo(this, 17, 57, this.textureX, this.textureY);
    this.bodyModel[16] = new ModelRendererTurbo(this, 49, 57, this.textureX, this.textureY);
    this.bodyModel[17] = new ModelRendererTurbo(this, 121, 9, this.textureX, this.textureY);
    this.bodyModel[18] = new ModelRendererTurbo(this, 121, 17, this.textureX, this.textureY);
    this.bodyModel[19] = new ModelRendererTurbo(this, 25, 41, this.textureX, this.textureY);
    this.bodyModel[20] = new ModelRendererTurbo(this, 49, 49, this.textureX, this.textureY);
    this.bodyModel[21] = new ModelRendererTurbo(this, 73, 49, this.textureX, this.textureY);
    this.bodyModel[22] = new ModelRendererTurbo(this, 65, 57, this.textureX, this.textureY);
    this.bodyModel[23] = new ModelRendererTurbo(this, 81, 57, this.textureX, this.textureY);
    this.bodyModel[24] = new ModelRendererTurbo(this, 97, 57, this.textureX, this.textureY);
    this.bodyModel[25] = new ModelRendererTurbo(this, 113, 57, this.textureX, this.textureY);
    this.bodyModel[26] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[27] = new ModelRendererTurbo(this, 1, 65, this.textureX, this.textureY);
    this.bodyModel[28] = new ModelRendererTurbo(this, 33, 65, this.textureX, this.textureY);
    this.bodyModel[29] = new ModelRendererTurbo(this, 65, 65, this.textureX, this.textureY);
    this.bodyModel[30] = new ModelRendererTurbo(this, 89, 65, this.textureX, this.textureY);
    this.bodyModel[31] = new ModelRendererTurbo(this, 1, 73, this.textureX, this.textureY);
    this.bodyModel[32] = new ModelRendererTurbo(this, 25, 73, this.textureX, this.textureY);
    this.bodyModel[33] = new ModelRendererTurbo(this, 89, 73, this.textureX, this.textureY);
    this.bodyModel[34] = new ModelRendererTurbo(this, 1, 81, this.textureX, this.textureY);
    this.bodyModel[35] = new ModelRendererTurbo(this, 25, 81, this.textureX, this.textureY);
    this.bodyModel[36] = new ModelRendererTurbo(this, 113, 65, this.textureX, this.textureY);
    this.bodyModel[37] = new ModelRendererTurbo(this, 49, 73, this.textureX, this.textureY);
    this.bodyModel[38] = new ModelRendererTurbo(this, 49, 81, this.textureX, this.textureY);
    this.bodyModel[39] = new ModelRendererTurbo(this, 65, 81, this.textureX, this.textureY);
    this.bodyModel[40] = new ModelRendererTurbo(this, 81, 81, this.textureX, this.textureY);
    this.bodyModel[41] = new ModelRendererTurbo(this, 97, 81, this.textureX, this.textureY);
    this.bodyModel[42] = new ModelRendererTurbo(this, 113, 81, this.textureX, this.textureY);
    this.bodyModel[43] = new ModelRendererTurbo(this, 81, 25, this.textureX, this.textureY);
    this.bodyModel[44] = new ModelRendererTurbo(this, 121, 25, this.textureX, this.textureY);
    this.bodyModel[45] = new ModelRendererTurbo(this, 121, 41, this.textureX, this.textureY);
    this.bodyModel[46] = new ModelRendererTurbo(this, 41, 33, this.textureX, this.textureY);
    this.bodyModel[47] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.bodyModel[48] = new ModelRendererTurbo(this, 89, 17, this.textureX, this.textureY);
    this.bodyModel[49] = new ModelRendererTurbo(this, 121, 49, this.textureX, this.textureY);
    this.bodyModel[50] = new ModelRendererTurbo(this, 1, 89, this.textureX, this.textureY);
    this.bodyModel[51] = new ModelRendererTurbo(this, 9, 89, this.textureX, this.textureY);
    this.bodyModel[52] = new ModelRendererTurbo(this, 25, 89, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.0F, 1.9F, -2.0F, 10, 10, 5, 0.0F, 0.1F, 0.5F, 0.1F, -1.9F, 0.5F, 0.1F, -1.9F, 0.5F, -0.9F, 0.1F, 0.5F, -0.9F, 0.1F, 0.0F, 0.1F, -1.9F, 0.0F, 0.1F, -1.9F, 0.0F, -0.9F, 0.1F, 0.0F, -0.9F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.0F, -0.1F, -2.0F, 4, 2, 4, 0.0F, 0.1F, 0.0F, 0.1F, -1.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(0.0F, -0.1F, -2.0F, 4, 2, 4, 0.0F, -1.0F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(-4.0F, 7.0F, -2.0F, 8, 4, 4, 0.0F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(-4.0F, 2.8F, -2.0F, 8, 4, 4, 0.0F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(-4.0F, -0.2F, -2.0F, 4, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, -0.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(0.0F, -0.2F, -2.0F, 4, 3, 4, 0.0F, 0.0F, -0.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(-3.5F, 4.6F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(-3.5F, 3.0F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-3.5F, 6.2F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(-3.5F, 7.8F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(-3.5F, 9.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-3.5F, 11.0F, -2.3F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(-4.0F, 0.0F, -2.4F, 4, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[14].addShapeBox(0.0F, 0.0F, -2.4F, 4, 3, 1, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F);
    this.bodyModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[15].addShapeBox(-3.5F, 3.0F, -2.4F, 3, 8, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[15].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[16].addShapeBox(0.25F, 3.0F, -2.4F, 3, 8, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[16].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[17].addShapeBox(-4.5F, 6.0F, -2.4F, 1, 5, 1, 0.0F, -0.2F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[17].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[18].addShapeBox(3.5F, 6.0F, -2.4F, 1, 5, 1, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, -0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, -0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[18].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[19].addShapeBox(-3.75F, 1.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F);
    this.bodyModel[19].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[20].addShapeBox(0.5F, 9.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[20].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[21].addShapeBox(0.5F, 7.8F, -2.45F, 3, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[21].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[22].addShapeBox(-0.5F, 6.2F, -2.45F, 4, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[22].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[23].addShapeBox(0.5F, 4.6F, -2.45F, 3, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[23].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[24].addShapeBox(-0.5F, 3.0F, -2.45F, 4, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[24].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[25].addShapeBox(0.75F, 1.4F, -2.45F, 3, 1, 1, 0.0F, -0.18F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, 0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F);
    this.bodyModel[25].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[26].addShapeBox(-0.5F, 8.8F, -2.45F, 1, 2, 1, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.bodyModel[26].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[27].addShapeBox(0.4F, 3.5F, -3.0F, 3, 2, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[27].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[28].addShapeBox(0.4F, 2.9F, -3.08F, 3, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[28].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[29].addShapeBox(-3.5F, 1.0F, 1.5F, 7, 9, 1, 0.0F, 0.5F, 0.5F, 0.5F, 0.5F, 0.5F, 0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 0.5F, 0.5F, 0.5F, 0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[29].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[30].addShapeBox(-3.5F, 4.3F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[30].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[31].addShapeBox(-3.5F, 2.7F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[31].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[32].addShapeBox(-3.5F, 1.1F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[32].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[33].addShapeBox(-3.5F, 5.9F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[33].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[34].addShapeBox(-3.5F, 7.5F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[34].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[35].addShapeBox(-3.5F, 9.1F, 1.6F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[35].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[36].addShapeBox(-2.0F, 1.0F, 2.3F, 4, 9, 1, 0.0F, -0.2F, -0.2F, 0.0F, -0.2F, -0.2F, 0.0F, -0.25F, -0.25F, 0.0F, -0.25F, -0.25F, 0.0F, -0.2F, -0.2F, 0.0F, -0.2F, -0.2F, 0.0F, -0.25F, -0.25F, 0.0F, -0.25F, -0.25F, 0.0F);
    this.bodyModel[36].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[37].addShapeBox(-1.5F, 7.5F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[37].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[38].addShapeBox(-1.5F, 5.9F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[38].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[39].addShapeBox(-1.5F, 4.3F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[39].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[40].addShapeBox(-1.5F, 2.7F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[40].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[41].addShapeBox(-1.5F, 1.25F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[41].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[42].addShapeBox(-1.5F, 8.95F, 2.35F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[42].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[43].addShapeBox(0.4F, 6.0F, -3.2F, 2, 4, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[43].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[44].addShapeBox(0.4F, 5.9F, -3.4F, 2, 2, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F);
    this.bodyModel[44].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[45].addShapeBox(-2.4F, 6.0F, -3.2F, 2, 4, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[45].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[46].addShapeBox(-2.4F, 5.9F, -3.4F, 2, 2, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F, 0.05F, -0.5F, 0.3F);
    this.bodyModel[46].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[47].addShapeBox(2.6F, 6.0F, -3.0F, 1, 3, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[47].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[48].addShapeBox(2.6F, 5.9F, -3.1F, 1, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[48].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[49].addShapeBox(-3.6F, 6.0F, -3.0F, 1, 3, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[49].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[50].addShapeBox(-3.6F, 5.9F, -3.1F, 1, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[50].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[51].addShapeBox(-3.4F, 3.5F, -3.0F, 3, 2, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[51].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[52].addShapeBox(-3.4F, 2.9F, -3.08F, 3, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[52].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel = new ModelRendererTurbo[2];
    this.leftArmModel[0] = new ModelRendererTurbo(this, 73, 1, this.textureX, this.textureY);
    this.leftArmModel[1] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    
    this.leftArmModel[0].addShapeBox(-1.0F, 4.5F, -2.0F, 5, 2, 5, 0.0F, 0.15F, 0.0F, 0.15F, -0.85F, 0.0F, 0.15F, -0.85F, 0.0F, -0.85F, 0.15F, 0.0F, -0.85F, 0.15F, -0.5F, 0.15F, -0.85F, -0.5F, 0.15F, -0.85F, -0.5F, -0.85F, 0.15F, -0.5F, -0.85F);
    this.leftArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel[1].addShapeBox(-1.0F, -2.1F, -2.0F, 5, 7, 5, 0.0F, 0.1F, 0.0F, 0.1F, -0.9F, 0.0F, 0.1F, -0.9F, 0.0F, -0.9F, 0.1F, 0.0F, -0.9F, 0.1F, 0.0F, 0.1F, -0.9F, 0.0F, 0.1F, -0.9F, 0.0F, -0.9F, 0.1F, 0.0F, -0.9F);
    this.leftArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel = new ModelRendererTurbo[2];
    this.rightArmModel[0] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
    this.rightArmModel[1] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    
    this.rightArmModel[0].addShapeBox(-3.0F, 4.5F, -2.0F, 5, 2, 5, 0.0F, 0.15F, 0.0F, 0.15F, -0.85F, 0.0F, 0.15F, -0.85F, 0.0F, -0.85F, 0.15F, 0.0F, -0.85F, 0.15F, -0.5F, 0.15F, -0.85F, -0.5F, 0.15F, -0.85F, -0.5F, -0.85F, 0.15F, -0.5F, -0.85F);
    this.rightArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel[1].addShapeBox(-3.0F, -2.1F, -2.0F, 5, 7, 5, 0.0F, 0.1F, 0.0F, 0.1F, -0.9F, 0.0F, 0.1F, -0.9F, 0.0F, -0.9F, 0.1F, 0.0F, -0.9F, 0.1F, 0.0F, 0.1F, -0.9F, 0.0F, 0.1F, -0.9F, 0.0F, -0.9F, 0.1F, 0.0F, -0.9F);
    this.rightArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
