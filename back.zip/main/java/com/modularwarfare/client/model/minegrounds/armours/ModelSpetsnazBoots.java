package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.model.ModelCustomArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelSpetsnazBoots
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelSpetsnazBoots()
  {
    this.leftFootModel = new ModelRendererTurbo[1];
    this.leftFootModel[0] = new ModelRendererTurbo(this, 25, 41, this.textureX, this.textureY);
    
    this.leftFootModel[0].addShapeBox(-2.0F, 7.0F, -2.4F, 4, 5, 5, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F);
    this.leftFootModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightFootModel = new ModelRendererTurbo[1];
    this.rightFootModel[0] = new ModelRendererTurbo(this, 41, 49, this.textureX, this.textureY);
    
    this.rightFootModel[0].addShapeBox(-2.0F, 7.0F, -2.4F, 4, 5, 5, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F);
    this.rightFootModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
