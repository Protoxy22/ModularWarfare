package com.modularwarfare.client.model.minegrounds;

import com.modularwarfare.api.WeaponAnimations;
import com.modularwarfare.client.model.ModelGun;
import com.modularwarfare.client.tmt.ModelRendererTurbo;
import org.lwjgl.util.vector.Vector3f;

public class ModelHAMR extends ModelGun {

	int textureX = 250;
	int textureY = 250;

	public ModelHAMR() {

		gunModel = new ModelRendererTurbo[1];

		gunModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		gunModel[0].addObj("guns/hamr/body");
		gunModel[0].setRotationPoint(0F, 0F, 0F);
		gunModel[0].setDefaultTexture("textures/hamr/camo.jpg");

		ammoModel = new ModelRendererTurbo[1];

		ammoModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		ammoModel[0].addObj("guns/hamr/ammo");
		ammoModel[0].setRotationPoint(0F, 0F, 0F);
		ammoModel[0].setDefaultTexture("textures/hamr/ammo.jpg");

		slideModel = new ModelRendererTurbo[1];

		slideModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 1
		slideModel[0].addObj("guns/hamr/slide");
		slideModel[0].setDefaultTexture("textures/hamr/camo.jpg");
		slideModel[0].setRotationPoint(0F, 0F, 0F);


		this.hasFlash = false;

		this.leftArmPos = new Vector3f(0.25F, -0.60F, 0.1F);
		this.leftArmRot = new Vector3f(80.0F, 35.0F, 0.0F);
		this.leftArmReloadPos = new Vector3f(-0.25F, -0.50F, -0.05F);
		this.leftArmReloadRot = new Vector3f(80.0F, 35.0F, 0.0F);


		this.rightArmPos = new Vector3f(0.40F, -0.70F, 0.0F);
		this.rightArmRot = new Vector3f(0.0F, 0.0F, -90.0F);
		this.rightArmReloadPos = new Vector3f(0.40F, -0.70F, 0.0F);
		this.rightArmReloadRot = new Vector3f(0.0F, 0.0F, -90.0F);

		this.leftHandAmmo = true;

		this.gunSlideDistance = 0.2F;
		this.reloadAnimation = WeaponAnimations.SIDE_CLIP;

		this.gunSlideDistance = 0.15F;

		this.muzzleFlashPointNormal = new Vector3f(3F, 0.0F, 1F);

		this.thirdPersonOffset = new Vector3f(0F, -0.15F, 0F);

		this.translateAll(0.1F, -1.6F, 0F);
		flipAll();
	}
}
