package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelMarineLegs
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelMarineLegs()
  {
    this.leftLegModel = new ModelRendererTurbo[1];
    this.leftLegModel[0] = new ModelRendererTurbo(this, 97, 89, this.textureX, this.textureY);
    
    this.leftLegModel[0].addShapeBox(-2.0F, -0.1F, -2.0F, 4, 8, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.leftLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel = new ModelRendererTurbo[1];
    this.rightLegModel[0] = new ModelRendererTurbo(this, 73, 89, this.textureX, this.textureY);
    
    this.rightLegModel[0].addShapeBox(-2.0F, -0.1F, -2.0F, 4, 8, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.rightLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
