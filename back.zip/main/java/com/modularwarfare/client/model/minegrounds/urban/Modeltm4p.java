package com.modularwarfare.client.model.minegrounds.urban;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;
import net.minecraft.client.model.*;

public class Modeltm4p extends ModelArmor
{
    int textureX;
    int textureY;
    
    public Modeltm4p() {
        this.textureX = 512;
        this.textureY = 512;
        this.leftLegModel = new ModelRendererTurbo[5];
        this.rightLegModel = new ModelRendererTurbo[33];
        this.initleftLegModel_1();
        this.initrightLegModel_1();
    }

    private void initleftLegModel_1() {
        this.leftLegModel[0] = new ModelRendererTurbo(this, 225, 25, this.textureX, this.textureY);
        this.leftLegModel[1] = new ModelRendererTurbo(this, 17, 41, this.textureX, this.textureY);
        this.leftLegModel[2] = new ModelRendererTurbo(this, 25, 41, this.textureX, this.textureY);
        this.leftLegModel[3] = new ModelRendererTurbo(this, 33, 41, this.textureX, this.textureY);
        this.leftLegModel[4] = new ModelRendererTurbo(this, 89, 41, this.textureX, this.textureY);
        this.leftLegModel[0].addShapeBox(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f);
        this.leftLegModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftLegModel[1].addShapeBox(-1.0f, 6.0f, -3.0f, 2, 1, 1, 0.0f, -0.1f, -0.5f, -0.7f, -8.326673E-17f, -0.5f, -0.7f, 0.1f, -0.5f, -0.1f, 0.0f, -0.5f, -0.1f, -0.2f, -0.1f, -0.7f, -0.1f, -0.1f, -0.7f, 0.1f, 0.0f, -0.1f, 0.0f, 0.0f, -0.1f);
        this.leftLegModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftLegModel[2].addShapeBox(-1.0f, 5.0f, -3.0f, 2, 1, 1, 0.0f, -0.1f, 3.6082248E-16f, -0.7f, 3.6082248E-16f, 3.6082248E-16f, -0.7f, 0.1f, 3.6082248E-16f, -0.1f, 0.0f, 3.6082248E-16f, -0.1f, -0.1f, 0.5f, -0.7f, 3.6082248E-16f, 0.5f, -0.7f, 0.1f, 0.5f, -0.1f, 0.0f, 0.5f, -0.1f);
        this.leftLegModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftLegModel[3].addShapeBox(-1.0f, 4.5f, -3.0f, 2, 1, 1, 0.0f, -0.2f, -0.1f, -0.7f, -0.1f, -0.1f, -0.7f, 0.1f, 0.0f, -0.1f, 0.0f, 0.0f, -0.1f, -0.1f, -0.5f, -0.7f, -8.326673E-17f, -0.5f, -0.7f, 0.1f, -0.5f, -0.1f, 0.0f, -0.5f, -0.1f);
        this.leftLegModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftLegModel[4].addShapeBox(-2.0f, 9.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f);
        this.leftLegModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
    }

    private void initrightLegModel_1() {
        this.rightLegModel[0] = new ModelRendererTurbo(this, 249, 25, this.textureX, this.textureY);
        this.rightLegModel[1] = new ModelRendererTurbo(this, 193, 17, this.textureX, this.textureY);
        this.rightLegModel[2] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
        this.rightLegModel[3] = new ModelRendererTurbo(this, 17, 33, this.textureX, this.textureY);
        this.rightLegModel[4] = new ModelRendererTurbo(this, 129, 25, this.textureX, this.textureY);
        this.rightLegModel[5] = new ModelRendererTurbo(this, 489, 25, this.textureX, this.textureY);
        this.rightLegModel[6] = new ModelRendererTurbo(this, 121, 33, this.textureX, this.textureY);
        this.rightLegModel[7] = new ModelRendererTurbo(this, 137, 33, this.textureX, this.textureY);
        this.rightLegModel[8] = new ModelRendererTurbo(this, 9, 33, this.textureX, this.textureY);
        this.rightLegModel[9] = new ModelRendererTurbo(this, 273, 33, this.textureX, this.textureY);
        this.rightLegModel[10] = new ModelRendererTurbo(this, 289, 33, this.textureX, this.textureY);
        this.rightLegModel[11] = new ModelRendererTurbo(this, 305, 33, this.textureX, this.textureY);
        this.rightLegModel[12] = new ModelRendererTurbo(this, 321, 33, this.textureX, this.textureY);
        this.rightLegModel[13] = new ModelRendererTurbo(this, 337, 33, this.textureX, this.textureY);
        this.rightLegModel[14] = new ModelRendererTurbo(this, 353, 33, this.textureX, this.textureY);
        this.rightLegModel[15] = new ModelRendererTurbo(this, 369, 33, this.textureX, this.textureY);
        this.rightLegModel[16] = new ModelRendererTurbo(this, 385, 33, this.textureX, this.textureY);
        this.rightLegModel[17] = new ModelRendererTurbo(this, 401, 33, this.textureX, this.textureY);
        this.rightLegModel[18] = new ModelRendererTurbo(this, 417, 33, this.textureX, this.textureY);
        this.rightLegModel[19] = new ModelRendererTurbo(this, 433, 33, this.textureX, this.textureY);
        this.rightLegModel[20] = new ModelRendererTurbo(this, 449, 33, this.textureX, this.textureY);
        this.rightLegModel[21] = new ModelRendererTurbo(this, 81, 33, this.textureX, this.textureY);
        this.rightLegModel[22] = new ModelRendererTurbo(this, 185, 33, this.textureX, this.textureY);
        this.rightLegModel[23] = new ModelRendererTurbo(this, 217, 33, this.textureX, this.textureY);
        this.rightLegModel[24] = new ModelRendererTurbo(this, 465, 33, this.textureX, this.textureY);
        this.rightLegModel[25] = new ModelRendererTurbo(this, 473, 33, this.textureX, this.textureY);
        this.rightLegModel[26] = new ModelRendererTurbo(this, 481, 33, this.textureX, this.textureY);
        this.rightLegModel[27] = new ModelRendererTurbo(this, 489, 33, this.textureX, this.textureY);
        this.rightLegModel[28] = new ModelRendererTurbo(this, 497, 33, this.textureX, this.textureY);
        this.rightLegModel[29] = new ModelRendererTurbo(this, 505, 33, this.textureX, this.textureY);
        this.rightLegModel[30] = new ModelRendererTurbo(this, 1, 41, this.textureX, this.textureY);
        this.rightLegModel[31] = new ModelRendererTurbo(this, 9, 41, this.textureX, this.textureY);
        this.rightLegModel[32] = new ModelRendererTurbo(this, 57, 41, this.textureX, this.textureY);
        this.rightLegModel[0].addShapeBox(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f);
        this.rightLegModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[1].addShapeBox(-3.0f, 1.0f, -2.0f, 1, 1, 4, 0.0f, -0.75f, 0.0f, 0.1f, -0.1f, 0.0f, 0.25f, -0.1f, 0.0f, 0.25f, -0.75f, 0.0f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f);
        this.rightLegModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[2].addShapeBox(-2.0f, 1.0f, -3.0f, 4, 1, 1, 0.0f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, 0.0f, -0.75f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, 0.0f);
        this.rightLegModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[3].addShapeBox(-2.0f, 1.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, -0.75f);
        this.rightLegModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[4].addShapeBox(2.0f, 1.25f, -2.0f, 1, 1, 4, 0.0f, -0.1f, 0.0f, 0.25f, -0.75f, 0.0f, 0.1f, -0.75f, 0.0f, 0.1f, -0.1f, 0.0f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f);
        this.rightLegModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[5].addShapeBox(2.0f, 3.25f, -2.0f, 1, 1, 4, 0.0f, -0.1f, 0.0f, 0.25f, -0.75f, 0.0f, 0.1f, -0.75f, 0.0f, 0.1f, -0.1f, 0.0f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f);
        this.rightLegModel[5].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[6].addShapeBox(-2.0f, 3.0f, -3.0f, 4, 1, 1, 0.0f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, 0.0f, -0.75f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, 0.0f);
        this.rightLegModel[6].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[7].addShapeBox(-2.0f, 3.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, 0.0f, 0.0f, 0.1f, 0.0f, -0.75f, 0.1f, -0.25f, -0.75f);
        this.rightLegModel[7].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[8].addShapeBox(-3.0f, 3.0f, -2.0f, 1, 1, 4, 0.0f, -0.75f, 0.0f, 0.1f, -0.1f, 0.0f, 0.25f, -0.1f, 0.0f, 0.25f, -0.75f, 0.0f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f);
        this.rightLegModel[8].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[9].addShapeBox(-2.0f, 1.0f, -3.0f, 4, 1, 1, 0.0f, -1.45f, 0.05f, -0.55f, -2.35f, -0.05f, -0.55f, -2.35f, 0.05f, 0.2f, -1.45f, 0.15f, 0.2f, -1.4f, -0.1f, -0.55f, -2.4f, -0.2f, -0.55f, -2.4f, -0.1f, 0.2f, -1.4f, 1.7208457E-15f, 0.2f);
        this.rightLegModel[9].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[10].addShapeBox(-2.0f, 1.0f, -3.0f, 4, 1, 1, 0.0f, -1.05f, 1.3600232E-15f, -0.55f, -2.55f, 0.05f, -0.55f, -2.55f, 0.15f, 0.2f, -1.05f, 0.1f, 0.2f, -1.0f, -0.25f, -0.55f, -2.6f, -0.1f, -0.55f, -2.6f, -4.1633363E-17f, 0.2f, -1.0f, -0.15f, 0.2f);
        this.rightLegModel[10].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[11].addShapeBox(-2.0f, 1.0f, -3.0f, 4, 1, 1, 0.0f, -1.85f, 0.05f, -0.55f, -1.65f, -0.1f, -0.55f, -1.65f, -4.1633363E-17f, 0.2f, -1.85f, 0.15f, 0.2f, -1.8f, -0.1f, -0.55f, -1.7f, -0.15f, -0.55f, -1.7f, -0.05f, 0.2f, -1.8f, -4.1633363E-17f, 0.2f);
        this.rightLegModel[11].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[12].addShapeBox(-2.0f, 1.0f, -3.0f, 4, 1, 1, 0.0f, -1.65f, -0.05f, -0.55f, -2.15f, 0.05f, -0.55f, -2.15f, 0.15f, 0.2f, -1.65f, 0.05f, 0.2f, -1.6f, -0.2f, -0.55f, -2.2f, -0.1f, -0.55f, -2.2f, -3.3584246E-15f, 0.2f, -1.6f, -0.1f, 0.2f);
        this.rightLegModel[12].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[13].addShapeBox(-2.0f, 3.0f, -3.0f, 4, 1, 1, 0.0f, -1.05f, -4.1633363E-17f, -0.55f, -2.55f, 0.05f, -0.55f, -2.55f, 0.15f, 0.2f, -1.05f, 0.1f, 0.2f, -1.0f, -0.25f, -0.55f, -2.6f, -0.1f, -0.55f, -2.6f, -4.1633363E-17f, 0.2f, -1.0f, -0.15f, 0.2f);
        this.rightLegModel[13].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[14].addShapeBox(-2.0f, 3.0f, -3.0f, 4, 1, 1, 0.0f, -1.45f, 0.05f, -0.55f, -2.35f, -0.05f, -0.55f, -2.35f, 0.05f, 0.2f, -1.45f, 0.15f, 0.2f, -1.4f, -0.1f, -0.55f, -2.4f, -0.2f, -0.55f, -2.4f, -0.1f, 0.2f, -1.4f, 1.7208457E-15f, 0.2f);
        this.rightLegModel[14].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[15].addShapeBox(-2.0f, 3.0f, -3.0f, 4, 1, 1, 0.0f, -1.65f, -0.05f, -0.55f, -2.15f, 0.05f, -0.55f, -2.15f, 0.15f, 0.2f, -1.65f, 0.05f, 0.2f, -1.6f, -0.2f, -0.55f, -2.2f, -0.1f, -0.55f, -2.2f, -3.3584246E-15f, 0.2f, -1.6f, -0.1f, 0.2f);
        this.rightLegModel[15].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[16].addShapeBox(-2.0f, 3.0f, -3.0f, 4, 1, 1, 0.0f, -1.85f, 0.05f, -0.55f, -1.65f, -0.1f, -0.55f, -1.65f, -4.1633363E-17f, 0.2f, -1.85f, 0.15f, 0.2f, -1.8f, -0.1f, -0.55f, -1.7f, -0.15f, -0.55f, -1.7f, -0.05f, 0.2f, -1.8f, -4.1633363E-17f, 0.2f);
        this.rightLegModel[16].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[17].addShapeBox(-2.0f, 3.0f, 2.0f, 4, 1, 1, 0.0f, -1.85f, 0.15f, 0.2f, -1.65f, -4.1633363E-17f, 0.2f, -1.65f, -0.1f, -0.55f, -1.85f, 0.05f, -0.55f, -1.8f, -4.1633363E-17f, 0.2f, -1.7f, -0.05f, 0.2f, -1.7f, -0.15f, -0.55f, -1.8f, -0.1f, -0.55f);
        this.rightLegModel[17].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[18].addShapeBox(-2.0f, 3.0f, 2.0f, 4, 1, 1, 0.0f, -1.65f, 0.05f, 0.2f, -2.15f, 0.15f, 0.2f, -2.15f, 0.05f, -0.55f, -1.65f, -0.05f, -0.55f, -1.6f, -0.1f, 0.2f, -2.2f, -3.3584246E-15f, 0.2f, -2.2f, -0.1f, -0.55f, -1.6f, -0.2f, -0.55f);
        this.rightLegModel[18].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[19].addShapeBox(-2.0f, 1.0f, 2.0f, 4, 1, 1, 0.0f, -1.65f, 0.05f, 0.2f, -2.15f, 0.15f, 0.2f, -2.15f, 0.05f, -0.55f, -1.65f, -0.05f, -0.55f, -1.6f, -0.1f, 0.2f, -2.2f, -3.3584246E-15f, 0.2f, -2.2f, -0.1f, -0.55f, -1.6f, -0.2f, -0.55f);
        this.rightLegModel[19].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[20].addShapeBox(-2.0f, 1.0f, 2.0f, 4, 1, 1, 0.0f, -1.85f, 0.15f, 0.2f, -1.65f, -4.1633363E-17f, 0.2f, -1.65f, -0.1f, -0.55f, -1.85f, 0.05f, -0.55f, -1.8f, -4.1633363E-17f, 0.2f, -1.7f, -0.05f, 0.2f, -1.7f, -0.15f, -0.55f, -1.8f, -0.1f, -0.55f);
        this.rightLegModel[20].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[21].addShapeBox(-3.0f, 2.0f, 0.0f, 1, 1, 1, 0.0f, -0.75f, 0.25f, -0.4f, -0.1f, 0.25f, -0.25f, -0.1f, 0.25f, 0.25f, -0.75f, 0.25f, 0.1f, -0.75f, 3.6082248E-16f, -0.4f, -0.1f, 3.6082248E-16f, -0.25f, -0.1f, 3.6082248E-16f, 0.25f, -0.75f, 3.6082248E-16f, 0.1f);
        this.rightLegModel[21].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[22].addShapeBox(-3.0f, 2.0f, -0.5f, 1, 1, 1, 0.0f, -0.2f, 0.5f, 0.7f, -0.2f, 0.5f, 0.4f, -0.2f, 0.5f, 0.4f, -0.2f, 0.5f, 0.7f, -0.2f, 1.2f, 0.0f, -0.2f, 1.2f, -0.2f, -0.2f, 1.0f, -0.3f, -0.2f, 1.0f, -0.1f);
        this.rightLegModel[22].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[23].addShapeBox(-3.0f, 2.0f, -0.5f, 1, 1, 1, 0.0f, 1.6653345E-16f, 0.5f, 0.4f, -0.8f, 0.5f, 0.7f, -0.8f, 0.5f, 0.7f, 1.6653345E-16f, 0.5f, 0.5f, 1.3877788E-16f, 0.9f, -0.3f, -0.8f, 1.2f, 0.0f, -0.8f, 1.0f, -0.1f, 1.3877788E-16f, 0.8f, -0.4f);
        this.rightLegModel[23].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[24].addShapeBox(-3.0f, 1.0f, -0.5f, 1, 1, 1, 0.0f, -0.2f, 1.0f, 0.5f, -0.2f, 1.0f, 0.3f, -0.2f, 1.0f, -0.7f, -0.2f, 1.0f, -0.5f, -0.2f, -0.5f, 0.7f, -0.2f, -0.5f, 0.4f, -0.2f, -0.5f, 0.4f, -0.2f, -0.5f, 0.7f);
        this.rightLegModel[24].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[25].addShapeBox(-3.0f, 1.0f, -0.5f, 1, 1, 1, 0.0f, 1.3877788E-16f, 0.9f, 0.2f, -0.8f, 1.0f, 0.5f, -0.8f, 1.0f, -0.5f, 1.3877788E-16f, 0.9f, -0.6f, 1.6653345E-16f, -0.5f, 0.4f, -0.8f, -0.5f, 0.7f, -0.8f, -0.5f, 0.7f, 1.6653345E-16f, -0.5f, 0.5f);
        this.rightLegModel[25].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[26].addShapeBox(-3.0f, 1.0f, 0.5f, 1, 1, 1, 0.0f, -0.1f, 0.9f, 0.7f, -0.1f, 0.9f, 0.7f, -0.2f, 1.0f, 0.0f, -0.2f, 1.0f, 0.0f, -0.1f, -1.0f, -0.2f, -0.1f, -1.0f, -0.2f, -0.3f, -1.2f, 0.0f, -0.3f, -1.2f, 0.0f);
        this.rightLegModel[26].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[27].addShapeBox(-3.0f, 1.0f, 0.5f, 1, 1, 1, 0.0f, -0.1f, 1.1f, -1.1f, -0.1f, 1.1f, -1.1f, -0.3f, 0.9f, 0.3f, -0.3f, 0.9f, 0.3f, -0.2f, -1.0f, -1.1f, -0.2f, -1.0f, -1.1f, -0.3f, -1.2f, 0.4f, -0.3f, -1.2f, 0.4f);
        this.rightLegModel[27].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[28].addShapeBox(-3.0f, 1.0f, 1.5f, 1, 1, 1, 0.0f, -0.2f, 0.9f, 0.1f, -0.2f, 0.9f, 0.1f, -0.1f, 1.1f, -0.9f, -0.1f, 1.1f, -0.9f, -0.3f, -1.2f, 0.1f, -0.3f, -1.2f, 0.1f, -0.2f, -1.0f, -0.9f, -0.2f, -1.0f, -0.9f);
        this.rightLegModel[28].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[29].addShapeBox(-1.0f, 5.0f, -3.0f, 2, 1, 1, 0.0f, -0.1f, 3.6082248E-16f, -0.7f, 3.6082248E-16f, 3.6082248E-16f, -0.7f, 0.1f, 3.6082248E-16f, -0.1f, 0.0f, 3.6082248E-16f, -0.1f, -0.1f, 0.5f, -0.7f, 3.6082248E-16f, 0.5f, -0.7f, 0.1f, 0.5f, -0.1f, 0.0f, 0.5f, -0.1f);
        this.rightLegModel[29].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[30].addShapeBox(-1.0f, 6.0f, -3.0f, 2, 1, 1, 0.0f, -0.1f, -0.5f, -0.7f, -8.326673E-17f, -0.5f, -0.7f, 0.1f, -0.5f, -0.1f, 0.0f, -0.5f, -0.1f, -0.2f, -0.1f, -0.7f, -0.1f, -0.1f, -0.7f, 0.1f, 0.0f, -0.1f, 0.0f, 0.0f, -0.1f);
        this.rightLegModel[30].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[31].addShapeBox(-1.0f, 4.5f, -3.0f, 2, 1, 1, 0.0f, -0.2f, -0.1f, -0.7f, -0.1f, -0.1f, -0.7f, 0.1f, 0.0f, -0.1f, 0.0f, 0.0f, -0.1f, -0.1f, -0.5f, -0.7f, -8.326673E-17f, -0.5f, -0.7f, 0.1f, -0.5f, -0.1f, 0.0f, -0.5f, -0.1f);
        this.rightLegModel[31].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightLegModel[32].addShapeBox(-2.0f, 9.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f);
        this.rightLegModel[32].setRotationPoint(0.0f, 0.0f, 0.0f);
    }
}
