package com.modularwarfare.client.model.minegrounds;

import com.modularwarfare.api.WeaponAnimations;
import com.modularwarfare.client.model.ModelGun;
import com.modularwarfare.client.tmt.ModelRendererTurbo;
import org.lwjgl.util.vector.Vector3f;

public class ModelSPAS12 extends ModelGun {

	int textureX = 256;
	int textureY = 256;

	public ModelSPAS12() {

		gunModel = new ModelRendererTurbo[1];

		gunModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		gunModel[0].addObj("guns/spas12/body");
		gunModel[0].setRotationPoint(0F, 0F, 0F);

		pumpModel = new ModelRendererTurbo[1];
		pumpModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		pumpModel[0].addObj("guns/spas12/pump");
		pumpModel[0].setRotationPoint(0F, 0F, 0F);

		slideModel = new ModelRendererTurbo[1];
		slideModel[0] = new ModelRendererTurbo(this, 0, 0, textureX, textureY); // Box 0
		slideModel[0].addObj("guns/spas12/slide");
		slideModel[0].setRotationPoint(0F, 0F, 0F);



		thirdPersonOffset = new Vector3f(0F, -.05F, 0F);//forward/up/?

		actionArm = EnumArm.Left;
		actionType = EnumAction.Bolt;
		rotationHelper = new Vector3f(0, 0.85F, 0);
		boltRotationPoint = new Vector3f(0, 0.85F, 0);
		boltRotation = 0F;

		gunSlideDistance = 0F;
		reloadAnimation = WeaponAnimations.SNIPER;
		rotateGunVertical = 05F;
		rotateGunHorizontal = 21F;
		tiltGun = -05F;
		/*tiltGunTime = 0.20F;
		unloadClipTime = 0.30F;
		loadClipTime = 0.35F;
		untiltGunTime = 0.15F;*/
		rotateClipVertical = -90F;
		rotateClipHorizontal = -1F;
		tiltClip = -08F;

		hasFlash = false;
		leftArmPos = new Vector3f(0.450F, -0.68F, 0.07F);
		leftArmRot = new Vector3f(65.0F, 30.0F, -45.0F);
		leftArmReloadPos = new Vector3f(0.450F, -0.68F, 0.07F);
		leftArmReloadRot = new Vector3f(65.0F, 30.0F, -45.0F);

		leftArmChargePos = new Vector3f(0.450F, -0.68F, 0.07F);
		leftArmChargeRot = new Vector3f(65.0F, 30.0F, -45.0F);

		rightArmPos = new Vector3f(0.43F, -0.59F, 0.0F);
		rightArmRot = new Vector3f(0.0F, 0.0F, -90.0F);
		rightArmReloadPos = new Vector3f(0.27F, -0.59F, 0.04F);
		rightArmReloadRot = new Vector3f(15F, 15F, -90.0F);


		rightArmScale = new Vector3f(0.7F, 0.8F, 0.7F);
		leftArmScale = new Vector3f(0.7F, 1.0F, 0.7F);

		leftHandAmmo = true;

		//RecoilSlideDistance = 0.16F;
		//RotateSlideDistance = -1F;

		pumpDelayAfterReload = 65;
		pumpDelay = 10;
		pumpTime = 20;
		gripIsOnPump = false;
		pumpHandleDistance = 0.45F;

		chargeModifier = new Vector3f (0.25F, -0.25F, -0.095F);

		crouchZoom = -0.45F;
		fancyStance = true;
		sprintRotate = new Vector3f(-20.0F, 30.0F, -0.0F);
		sprintTranslate = new Vector3f(0.5F, -0.10F, -0.65F);

		this.thirdPersonOffset = new Vector3f(0F, -0.15F, 0F);
		this.translateAll(0F, -1F, 0F);
		flipAll();
	}
}
