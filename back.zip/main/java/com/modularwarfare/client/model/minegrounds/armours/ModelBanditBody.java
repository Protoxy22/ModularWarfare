package com.modularwarfare.client.model.minegrounds.armours;


import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelBanditBody extends ModelArmor {
  int textureX = 128;
  int textureY = 128;
  
  public ModelBanditBody()
  {
    this.bodyModel = new ModelRendererTurbo[34];
    this.bodyModel[0] = new ModelRendererTurbo(this, 89, 17, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 65, 25, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 41, 49, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 1, 41, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 73, 49, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 97, 49, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 73, 57, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 97, 57, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 1, 65, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 113, 17, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 49, 33, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 33, 65, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, 49, 65, this.textureX, this.textureY);
    this.bodyModel[14] = new ModelRendererTurbo(this, 121, 17, this.textureX, this.textureY);
    this.bodyModel[15] = new ModelRendererTurbo(this, 121, 25, this.textureX, this.textureY);
    this.bodyModel[16] = new ModelRendererTurbo(this, 89, 33, this.textureX, this.textureY);
    this.bodyModel[17] = new ModelRendererTurbo(this, 17, 33, this.textureX, this.textureY);
    this.bodyModel[18] = new ModelRendererTurbo(this, 97, 33, this.textureX, this.textureY);
    this.bodyModel[19] = new ModelRendererTurbo(this, 121, 33, this.textureX, this.textureY);
    this.bodyModel[20] = new ModelRendererTurbo(this, 1, 49, this.textureX, this.textureY);
    this.bodyModel[21] = new ModelRendererTurbo(this, 65, 65, this.textureX, this.textureY);
    this.bodyModel[22] = new ModelRendererTurbo(this, 121, 49, this.textureX, this.textureY);
    this.bodyModel[23] = new ModelRendererTurbo(this, 89, 65, this.textureX, this.textureY);
    this.bodyModel[24] = new ModelRendererTurbo(this, 17, 9, this.textureX, this.textureY);
    this.bodyModel[25] = new ModelRendererTurbo(this, 89, 9, this.textureX, this.textureY);
    this.bodyModel[26] = new ModelRendererTurbo(this, 105, 65, this.textureX, this.textureY);
    this.bodyModel[27] = new ModelRendererTurbo(this, 89, 49, this.textureX, this.textureY);
    this.bodyModel[28] = new ModelRendererTurbo(this, 33, 57, this.textureX, this.textureY);
    this.bodyModel[29] = new ModelRendererTurbo(this, 1, 73, this.textureX, this.textureY);
    this.bodyModel[30] = new ModelRendererTurbo(this, 17, 73, this.textureX, this.textureY);
    this.bodyModel[31] = new ModelRendererTurbo(this, 121, 57, this.textureX, this.textureY);
    this.bodyModel[32] = new ModelRendererTurbo(this, 1, 65, this.textureX, this.textureY);
    this.bodyModel[33] = new ModelRendererTurbo(this, 25, 65, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.0F, 1.9F, -2.0F, 8, 10, 4, 0.0F, 0.1F, 0.5F, 0.1F, 0.1F, 0.5F, 0.1F, 0.1F, 0.5F, 0.1F, 0.1F, 0.5F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.0F, -0.1F, -2.0F, 4, 2, 4, 0.0F, 0.1F, 0.0F, 0.1F, -1.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(0.0F, -0.1F, -2.0F, 4, 2, 4, 0.0F, -1.0F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F, 0.1F, -0.5F, 0.1F, 0.0F, -0.5F, 0.1F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(-4.0F, 2.1F, -2.0F, 8, 8, 4, 0.0F, 0.0F, 0.3F, 0.5F, 0.0F, 0.3F, 0.5F, 0.0F, 0.3F, 0.5F, 0.0F, 0.3F, 0.5F, 0.3F, 0.3F, 0.5F, 0.3F, 0.3F, 0.5F, 0.3F, 0.3F, 0.5F, 0.3F, 0.3F, 0.5F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(-4.0F, -0.2F, -2.0F, 4, 2, 4, 0.0F, 0.5F, 0.0F, 0.2F, -1.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.5F, 0.0F, 0.2F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(0.0F, -0.2F, -2.0F, 4, 2, 4, 0.0F, -1.0F, 0.0F, 0.2F, 0.5F, 0.0F, 0.2F, 0.5F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(-3.0F, 1.8F, 1.4F, 6, 4, 2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8F, 0.0F, 0.0F, -0.8F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8F, 0.0F, 0.0F, -0.8F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(-3.0F, 1.8F, 1.5F, 6, 1, 2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8F, 0.0F, 0.0F, -0.8F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, -0.8F, -0.2F, 0.0F, -0.8F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(-3.0F, 5.8F, 1.4F, 6, 1, 2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8F, 0.0F, 0.0F, -0.8F, -0.25F, -0.7F, 0.0F, -0.25F, -0.7F, 0.0F, -0.25F, -0.7F, -0.8F, -0.25F, -0.7F, -0.8F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-4.0F, 10.7F, -2.5F, 8, 1, 5, 0.0F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F, 0.15F, 0.1F, -0.3F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(-1.0F, 10.7F, -2.3F, 2, 1, 1, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(-1.8F, 4.9F, -3.6F, 2, 5, 2, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-0.15F, 4.9F, -3.6F, 2, 5, 2, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(1.5F, 4.9F, -3.6F, 2, 5, 2, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[14].addShapeBox(-1.8F, 5.5F, -3.6F, 2, 3, 1, 0.0F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F);
    this.bodyModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[15].addShapeBox(1.5F, 5.5F, -3.6F, 2, 3, 1, 0.0F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F);
    this.bodyModel[15].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[16].addShapeBox(-0.15F, 5.5F, -3.6F, 2, 3, 1, 0.0F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F);
    this.bodyModel[16].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[17].addShapeBox(-3.0F, -0.2F, -2.7F, 1, 2, 1, 0.0F, 0.0F, 0.15F, -0.35F, 0.0F, 0.15F, -0.35F, 0.0F, 0.15F, -0.25F, 0.0F, 0.15F, -0.25F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F);
    this.bodyModel[17].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[18].addShapeBox(-3.0F, 1.8F, -2.7F, 1, 4, 1, 0.0F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F);
    this.bodyModel[18].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[19].addShapeBox(2.0F, 1.8F, -2.7F, 1, 4, 1, 0.0F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F);
    this.bodyModel[19].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[20].addShapeBox(2.0F, -0.2F, -2.7F, 1, 2, 1, 0.0F, 0.0F, 0.15F, -0.35F, 0.0F, 0.15F, -0.35F, 0.0F, 0.15F, -0.25F, 0.0F, 0.15F, -0.25F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.05F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F);
    this.bodyModel[20].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[21].addShapeBox(-4.0F, 5.0F, -2.7F, 8, 5, 1, 0.0F, 0.2F, -0.4F, 0.0F, 0.2F, -0.4F, 0.0F, 0.2F, -0.4F, 0.0F, 0.2F, -0.4F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F);
    this.bodyModel[21].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[22].addShapeBox(-3.5F, 5.5F, -3.6F, 2, 3, 1, 0.0F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.0F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F, -0.3F, 0.5F, 0.1F);
    this.bodyModel[22].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[23].addShapeBox(-3.5F, 4.9F, -3.6F, 2, 5, 2, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, -0.7F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[23].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[24].addShapeBox(-3.0F, -0.35F, -1.95F, 1, 1, 4, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[24].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[25].addShapeBox(2.0F, -0.35F, -1.95F, 1, 1, 4, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[25].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[26].addShapeBox(-2.0F, 1.65F, 1.9F, 6, 7, 1, 0.0F, 0.0F, 0.0F, 0.0F, -5.0F, 0.0F, 0.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.2F, 0.0F, 0.0F, 0.2F, -1.0F, 0.0F, 0.2F, -1.0F, -0.3F, -6.2F, 0.0F, -0.3F);
    this.bodyModel[26].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[27].addShapeBox(-3.0F, -0.35F, 1.9F, 2, 2, 1, 0.0F, 0.0F, 0.0F, -0.15F, -1.0F, 0.0F, -0.15F, -1.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F);
    this.bodyModel[27].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[28].addShapeBox(1.0F, -0.35F, 1.8F, 2, 2, 1, 0.0F, -1.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.5F, -1.0F, 0.0F, -0.5F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[28].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[29].addShapeBox(-4.0F, 1.65F, 1.8F, 6, 7, 1, 0.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -5.0F, 0.0F, 0.0F, 0.2F, -1.0F, 0.0F, -6.2F, 0.0F, 0.0F, -6.2F, 0.0F, -0.2F, 0.2F, -1.0F, -0.2F);
    this.bodyModel[29].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[30].addShapeBox(-4.0F, 8.7F, -2.5F, 8, 1, 5, 0.0F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F, 0.3F, 0.1F, 0.1F);
    this.bodyModel[30].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[31].addShapeBox(2.0F, 2.0F, -3.2F, 1, 3, 1, 0.0F, 0.25F, 0.0F, 0.2F, 0.25F, 0.0F, 0.2F, 0.25F, 0.0F, 0.2F, 0.25F, 0.0F, 0.2F, 0.25F, -0.5F, 0.2F, 0.25F, -0.5F, 0.2F, 0.25F, -0.5F, 0.2F, 0.25F, -0.5F, 0.2F);
    this.bodyModel[31].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[32].addShapeBox(2.0F, 1.9F, -3.2F, 1, 1, 1, 0.0F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F);
    this.bodyModel[32].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[33].addShapeBox(2.0F, 2.9F, -3.2F, 1, 1, 1, 0.0F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.0F, -0.5F, 0.3F, 0.0F, -0.5F, 0.3F, 0.0F, -0.5F, 0.3F, 0.0F, -0.5F, 0.3F);
    this.bodyModel[33].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel = new ModelRendererTurbo[2];
    this.leftArmModel[0] = new ModelRendererTurbo(this, 73, 1, this.textureX, this.textureY);
    this.leftArmModel[1] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    
    this.leftArmModel[0].addShapeBox(-1.0F, 4.5F, -2.0F, 4, 2, 4, 0.0F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F);
    this.leftArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel[1].addShapeBox(-1.0F, -2.1F, -2.0F, 4, 7, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.leftArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel = new ModelRendererTurbo[2];
    this.rightArmModel[0] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
    this.rightArmModel[1] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    
    this.rightArmModel[0].addShapeBox(-3.0F, 4.5F, -2.0F, 4, 2, 4, 0.0F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, 0.0F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F, 0.15F, -0.5F, 0.15F);
    this.rightArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel[1].addShapeBox(-3.0F, -2.1F, -2.0F, 4, 7, 4, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.rightArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
