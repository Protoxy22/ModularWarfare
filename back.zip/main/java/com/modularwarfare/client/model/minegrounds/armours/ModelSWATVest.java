package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelSWATVest
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelSWATVest()
  {
    this.bodyModel = new ModelRendererTurbo[57];
    this.bodyModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 33, 1, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 65, 1, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 89, 1, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 57, 1, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 81, 1, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 105, 1, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 25, 9, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 57, 9, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 81, 9, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 97, 9, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.bodyModel[14] = new ModelRendererTurbo(this, 121, 1, this.textureX, this.textureY);
    this.bodyModel[15] = new ModelRendererTurbo(this, 17, 17, this.textureX, this.textureY);
    this.bodyModel[16] = new ModelRendererTurbo(this, 25, 17, this.textureX, this.textureY);
    this.bodyModel[17] = new ModelRendererTurbo(this, 41, 17, this.textureX, this.textureY);
    this.bodyModel[18] = new ModelRendererTurbo(this, 57, 17, this.textureX, this.textureY);
    this.bodyModel[19] = new ModelRendererTurbo(this, 73, 17, this.textureX, this.textureY);
    this.bodyModel[20] = new ModelRendererTurbo(this, 89, 17, this.textureX, this.textureY);
    this.bodyModel[21] = new ModelRendererTurbo(this, 17, 25, this.textureX, this.textureY);
    this.bodyModel[22] = new ModelRendererTurbo(this, 33, 25, this.textureX, this.textureY);
    this.bodyModel[23] = new ModelRendererTurbo(this, 105, 17, this.textureX, this.textureY);
    this.bodyModel[24] = new ModelRendererTurbo(this, 49, 25, this.textureX, this.textureY);
    this.bodyModel[25] = new ModelRendererTurbo(this, 65, 25, this.textureX, this.textureY);
    this.bodyModel[26] = new ModelRendererTurbo(this, 81, 25, this.textureX, this.textureY);
    this.bodyModel[27] = new ModelRendererTurbo(this, 97, 25, this.textureX, this.textureY);
    this.bodyModel[28] = new ModelRendererTurbo(this, 105, 25, this.textureX, this.textureY);
    this.bodyModel[29] = new ModelRendererTurbo(this, 121, 25, this.textureX, this.textureY);
    this.bodyModel[30] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.bodyModel[31] = new ModelRendererTurbo(this, 9, 33, this.textureX, this.textureY);
    this.bodyModel[32] = new ModelRendererTurbo(this, 17, 33, this.textureX, this.textureY);
    this.bodyModel[33] = new ModelRendererTurbo(this, 33, 33, this.textureX, this.textureY);
    this.bodyModel[34] = new ModelRendererTurbo(this, 121, 17, this.textureX, this.textureY);
    this.bodyModel[35] = new ModelRendererTurbo(this, 41, 33, this.textureX, this.textureY);
    this.bodyModel[36] = new ModelRendererTurbo(this, 57, 33, this.textureX, this.textureY);
    this.bodyModel[37] = new ModelRendererTurbo(this, 81, 33, this.textureX, this.textureY);
    this.bodyModel[38] = new ModelRendererTurbo(this, 105, 33, this.textureX, this.textureY);
    this.bodyModel[39] = new ModelRendererTurbo(this, 1, 41, this.textureX, this.textureY);
    this.bodyModel[40] = new ModelRendererTurbo(this, 25, 41, this.textureX, this.textureY);
    this.bodyModel[41] = new ModelRendererTurbo(this, 49, 41, this.textureX, this.textureY);
    this.bodyModel[42] = new ModelRendererTurbo(this, 73, 41, this.textureX, this.textureY);
    this.bodyModel[43] = new ModelRendererTurbo(this, 81, 41, this.textureX, this.textureY);
    this.bodyModel[44] = new ModelRendererTurbo(this, 89, 41, this.textureX, this.textureY);
    this.bodyModel[45] = new ModelRendererTurbo(this, 9, 25, this.textureX, this.textureY);
    this.bodyModel[46] = new ModelRendererTurbo(this, 97, 41, this.textureX, this.textureY);
    this.bodyModel[47] = new ModelRendererTurbo(this, 105, 41, this.textureX, this.textureY);
    this.bodyModel[48] = new ModelRendererTurbo(this, 113, 41, this.textureX, this.textureY);
    this.bodyModel[49] = new ModelRendererTurbo(this, 121, 41, this.textureX, this.textureY);
    this.bodyModel[50] = new ModelRendererTurbo(this, 1, 49, this.textureX, this.textureY);
    this.bodyModel[51] = new ModelRendererTurbo(this, 9, 49, this.textureX, this.textureY);
    this.bodyModel[52] = new ModelRendererTurbo(this, 17, 49, this.textureX, this.textureY);
    this.bodyModel[53] = new ModelRendererTurbo(this, 25, 49, this.textureX, this.textureY);
    this.bodyModel[54] = new ModelRendererTurbo(this, -81, 57, this.textureX, this.textureY);
    this.bodyModel[55] = new ModelRendererTurbo(this, 12, 92, this.textureX, this.textureY);
    this.bodyModel[56] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.0F, 7.0F, -2.0F, 8, 4, 4, 0.0F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.2F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.0F, 2.8F, -2.0F, 8, 4, 4, 0.0F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(-4.0F, -0.2F, -2.0F, 4, 3, 4, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, -0.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(0.0F, -0.2F, -2.0F, 4, 3, 4, 0.0F, 0.0F, -0.7F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(-3.5F, 4.6F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(-3.5F, 3.0F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(-3.5F, 6.2F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(-3.5F, 7.8F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(-3.5F, 9.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-3.5F, 11.0F, -2.3F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(-4.0F, 0.0F, -2.4F, 4, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(0.0F, 0.0F, -2.4F, 4, 3, 1, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-3.5F, 3.0F, -2.4F, 3, 8, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(0.25F, 3.0F, -2.4F, 3, 8, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[14].addShapeBox(-4.5F, 6.0F, -2.4F, 1, 5, 1, 0.0F, -0.2F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F);
    this.bodyModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[15].addShapeBox(3.5F, 6.0F, -2.4F, 1, 5, 1, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, -0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, -0.1F, -0.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[15].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[16].addShapeBox(-3.75F, 1.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F);
    this.bodyModel[16].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[17].addShapeBox(0.5F, 9.4F, -2.45F, 3, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[17].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[18].addShapeBox(0.5F, 7.8F, -2.45F, 3, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[18].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[19].addShapeBox(-0.5F, 6.2F, -2.45F, 4, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[19].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[20].addShapeBox(0.5F, 4.6F, -2.45F, 3, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[20].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[21].addShapeBox(-0.5F, 3.0F, -2.45F, 4, 1, 1, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F);
    this.bodyModel[21].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[22].addShapeBox(0.75F, 1.4F, -2.45F, 3, 1, 1, 0.0F, -0.18F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.18F, 0.0F, 0.0F, 0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F, -0.15F, -0.2F, 0.0F, 0.15F, -0.2F, 0.0F);
    this.bodyModel[22].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[23].addShapeBox(-0.5F, 8.8F, -2.45F, 1, 2, 1, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.bodyModel[23].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[24].addShapeBox(-4.0F, 0.0F, 1.4F, 4, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F);
    this.bodyModel[24].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[25].addShapeBox(0.0F, 0.0F, 1.4F, 4, 3, 1, 0.0F, -1.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F);
    this.bodyModel[25].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[26].addShapeBox(-3.0F, 3.0F, 1.4F, 6, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.75F, 0.0F, 0.0F, -0.75F, 0.0F, 0.0F, -0.75F, 0.0F, 0.0F, -0.75F, 0.0F, 0.0F);
    this.bodyModel[26].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[27].addShapeBox(-4.0F, 5.0F, -3.3F, 2, 4, 1, 0.0F, -0.25F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F);
    this.bodyModel[27].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[28].addShapeBox(-3.95F, 4.9F, -3.35F, 2, 2, 2, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F);
    this.bodyModel[28].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[29].addShapeBox(-2.1F, 5.0F, -3.3F, 2, 4, 1, 0.0F, -0.15F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.25F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F);
    this.bodyModel[29].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[30].addShapeBox(-3.3F, 1.0F, -2.7F, 2, 2, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[30].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[31].addShapeBox(-3.3F, 0.9F, -2.78F, 2, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[31].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[32].addShapeBox(-2.15F, 4.9F, -3.35F, 2, 2, 2, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, 0.0F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F, -0.15F, -0.5F, 0.0F);
    this.bodyModel[32].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[33].addShapeBox(0.3F, 5.0F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[33].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[34].addShapeBox(0.3F, 4.9F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[34].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[35].addShapeBox(-3.0F, 1.6F, 1.5F, 6, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[35].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[36].addShapeBox(-3.5F, 4.3F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[36].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[37].addShapeBox(-3.5F, 2.7F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[37].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[38].addShapeBox(-3.5F, 1.1F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[38].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[39].addShapeBox(-3.5F, 5.9F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[39].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[40].addShapeBox(-3.5F, 7.5F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[40].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[41].addShapeBox(-3.5F, 9.1F, 1.35F, 7, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[41].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[42].addShapeBox(1.3F, 1.0F, -2.7F, 2, 2, 1, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F);
    this.bodyModel[42].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[43].addShapeBox(1.3F, 0.9F, -2.78F, 2, 1, 1, 0.0F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F, 0.05F, 0.0F, 0.3F);
    this.bodyModel[43].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[44].addShapeBox(1.45F, 5.0F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[44].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[45].addShapeBox(1.45F, 4.9F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[45].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[46].addShapeBox(2.6F, 5.0F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[46].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[47].addShapeBox(2.6F, 4.9F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[47].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[48].addShapeBox(0.3F, 7.3F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[48].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[49].addShapeBox(0.3F, 7.2F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[49].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[50].addShapeBox(1.45F, 7.3F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[50].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[51].addShapeBox(1.45F, 7.2F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[51].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[52].addShapeBox(2.6F, 7.3F, -3.3F, 1, 2, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[52].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[53].addShapeBox(2.6F, 7.2F, -3.35F, 1, 1, 2, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, 0.0F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F, 0.02F, -0.3F, 0.0F);
    this.bodyModel[53].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[54].addShapeBox(-2.75F, 2.0F, 1.51F, 100, 29, 1, 0.0F, 0.0F, 0.0F, 0.0F, -94.5F, 0.0F, 0.0F, -94.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -27.0F, 0.0F, -94.5F, -27.0F, 0.0F, -94.5F, -27.0F, 0.0F, 0.0F, -27.0F, 0.0F);
    this.bodyModel[54].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[55].addShapeBox(-2.9F, 3.7F, -2.46F, 100, 29, 1, 0.0F, 0.0F, 0.0F, 0.0F, -98.0F, 0.0F, 0.0F, -98.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -28.0F, 0.0F, -98.0F, -28.0F, 0.0F, -98.0F, -28.0F, 0.0F, 0.0F, -28.0F, 0.0F);
    this.bodyModel[55].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[56].addShapeBox(-3.0F, 3.8F, -2.45F, 2, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.25F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.25F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.bodyModel[56].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
