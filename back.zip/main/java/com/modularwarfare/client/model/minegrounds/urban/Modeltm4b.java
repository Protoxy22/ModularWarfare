package com.modularwarfare.client.model.minegrounds.urban;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class Modeltm4b extends ModelArmor {
    int textureX;
    int textureY;
    
    public Modeltm4b() {
        this.textureX = 512;
        this.textureY = 512;
        this.leftFootModel = new ModelRendererTurbo[5];
        this.rightFootModel = new ModelRendererTurbo[5];
        this.initleftFootModel_1();
        this.initrightFootModel_1();
    }
    
    private void initleftFootModel_1() {
        this.leftFootModel[0] = new ModelRendererTurbo(this, 73, 41, this.textureX, this.textureY);
        this.leftFootModel[1] = new ModelRendererTurbo(this, 145, 33, this.textureX, this.textureY);
        this.leftFootModel[2] = new ModelRendererTurbo(this, 89, 41, this.textureX, this.textureY);
        this.leftFootModel[3] = new ModelRendererTurbo(this, 281, 33, this.textureX, this.textureY);
        this.leftFootModel[4] = new ModelRendererTurbo(this, 153, 41, this.textureX, this.textureY);
        this.leftFootModel[0].addShapeBox(-2.0f, 9.0f, -3.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f);
        this.leftFootModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftFootModel[1].addShapeBox(-3.0f, 9.0f, -2.0f, 1, 1, 4, 0.0f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, 0.1f, 0.1f, -0.1f, 0.1f, 0.25f, -0.1f, 0.1f, 0.25f, -0.75f, 0.1f, 0.1f);
        this.leftFootModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftFootModel[2].addShapeBox(-2.0f, 9.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f);
        this.leftFootModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftFootModel[3].addShapeBox(2.0f, 9.0f, -2.0f, 1, 1, 4, 0.0f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, 0.1f, 0.25f, -0.75f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.1f, 0.1f, 0.25f);
        this.leftFootModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftFootModel[4].addShapeBox(-2.0f, 10.0f, -2.0f, 4, 2, 4, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        this.leftFootModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
    }
    
    private void initrightFootModel_1() {
        this.rightFootModel[0] = new ModelRendererTurbo(this, 73, 33, this.textureX, this.textureY);
        this.rightFootModel[1] = new ModelRendererTurbo(this, 41, 41, this.textureX, this.textureY);
        this.rightFootModel[2] = new ModelRendererTurbo(this, 129, 33, this.textureX, this.textureY);
        this.rightFootModel[3] = new ModelRendererTurbo(this, 57, 41, this.textureX, this.textureY);
        this.rightFootModel[4] = new ModelRendererTurbo(this, 97, 41, this.textureX, this.textureY);
        this.rightFootModel[0].addShapeBox(-3.0f, 9.0f, -2.0f, 1, 1, 4, 0.0f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, 0.1f, 0.1f, -0.1f, 0.1f, 0.25f, -0.1f, 0.1f, 0.25f, -0.75f, 0.1f, 0.1f);
        this.rightFootModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightFootModel[1].addShapeBox(-2.0f, 9.0f, -3.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f);
        this.rightFootModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightFootModel[2].addShapeBox(2.0f, 9.0f, -2.0f, 1, 1, 4, 0.0f, -0.1f, -0.25f, 0.25f, -0.75f, -0.25f, 0.1f, -0.75f, -0.25f, 0.1f, -0.1f, -0.25f, 0.25f, -0.1f, 0.1f, 0.25f, -0.75f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.1f, 0.1f, 0.25f);
        this.rightFootModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightFootModel[3].addShapeBox(-2.0f, 9.0f, 2.0f, 4, 1, 1, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, 0.0f, 0.1f, -0.25f, -0.75f, 0.1f, -0.25f, -0.75f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, -0.75f, 0.1f, 0.1f, -0.75f);
        this.rightFootModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightFootModel[4].addShapeBox(-2.0f, 10.0f, -2.0f, 4, 2, 4, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        this.rightFootModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
    }
}
