package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelkskChest
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelkskChest()
  {
    this.bodyModel = new ModelRendererTurbo[15];
    this.bodyModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[1] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.bodyModel[2] = new ModelRendererTurbo(this, 105, 1, this.textureX, this.textureY);
    this.bodyModel[3] = new ModelRendererTurbo(this, 113, 1, this.textureX, this.textureY);
    this.bodyModel[4] = new ModelRendererTurbo(this, 121, 1, this.textureX, this.textureY);
    this.bodyModel[5] = new ModelRendererTurbo(this, 57, 1, this.textureX, this.textureY);
    this.bodyModel[6] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    this.bodyModel[7] = new ModelRendererTurbo(this, 97, 9, this.textureX, this.textureY);
    this.bodyModel[8] = new ModelRendererTurbo(this, 105, 9, this.textureX, this.textureY);
    this.bodyModel[9] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
    this.bodyModel[10] = new ModelRendererTurbo(this, 33, 33, this.textureX, this.textureY);
    this.bodyModel[11] = new ModelRendererTurbo(this, 73, 41, this.textureX, this.textureY);
    this.bodyModel[12] = new ModelRendererTurbo(this, 1, 73, this.textureX, this.textureY);
    this.bodyModel[13] = new ModelRendererTurbo(this, 49, 33, this.textureX, this.textureY);
    this.bodyModel[14] = new ModelRendererTurbo(this, 33, 73, this.textureX, this.textureY);
    
    this.bodyModel[0].addShapeBox(-4.5F, 0.0F, -4.0F, 16, 18, 8, 0.0F, 0.2F, 0.2F, -1.8F, -6.8F, 0.2F, -1.8F, -6.8F, 0.2F, -1.8F, 0.2F, 0.2F, -1.8F, 0.2F, -5.8F, -1.8F, -6.8F, -5.8F, -1.8F, -6.8F, -5.8F, -1.8F, 0.2F, -5.8F, -1.8F);
    this.bodyModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[1].addShapeBox(-4.4F, 7.0F, -3.0F, 2, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[2].addShapeBox(-2.2F, 7.0F, -3.0F, 2, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[3].addShapeBox(0.2F, 7.0F, -3.0F, 2, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[4].addShapeBox(2.4F, 7.0F, -3.0F, 2, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[5].addShapeBox(-4.4F, 7.0F, -3.2F, 2, 1, 1, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[6].addShapeBox(-2.2F, 7.0F, -3.2F, 2, 1, 1, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[7].addShapeBox(0.2F, 7.0F, -3.2F, 2, 1, 1, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[8].addShapeBox(2.4F, 7.0F, -3.2F, 2, 1, 1, 0.0F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[9].addShapeBox(-4.4F, 7.0F, 2.0F, 4, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[10].addShapeBox(0.4F, 7.0F, 2.0F, 4, 3, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[11].addShapeBox(0.4F, 6.5F, 2.2F, 4, 1, 1, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F);
    this.bodyModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[12].addShapeBox(-4.4F, 6.5F, 2.2F, 4, 1, 1, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F, 0.2F, 0.0F, 0.0F);
    this.bodyModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[13].addShapeBox(-4.4F, 1.0F, -3.0F, 3, 4, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.bodyModel[14].addShapeBox(1.6F, 1.0F, -3.0F, 3, 4, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.bodyModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel = new ModelRendererTurbo[2];
    this.leftArmModel[0] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.leftArmModel[1] = new ModelRendererTurbo(this, 89, 1, this.textureX, this.textureY);
    
    this.leftArmModel[0].addShapeBox(-0.9F, -2.0F, -2.0F, 8, 24, 8, 0.0F, 0.1F, 0.1F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -11.9F, 0.1F, -3.9F, -11.9F, 0.1F, -3.9F, -11.9F, -3.9F, 0.1F, -11.9F, -3.9F);
    this.leftArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.leftArmModel[1].addShapeBox(2.45F, 1.0F, -1.5F, 1, 2, 3, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.leftArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel = new ModelRendererTurbo[2];
    this.rightArmModel[0] = new ModelRendererTurbo(this, 57, 1, this.textureX, this.textureY);
    this.rightArmModel[1] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
    
    this.rightArmModel[0].addShapeBox(-3.1F, -2.0F, -2.0F, 8, 24, 8, 0.0F, 0.1F, 0.1F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -3.9F, 0.1F, 0.1F, -3.9F, 0.1F, -11.9F, 0.1F, -3.9F, -11.9F, 0.1F, -3.9F, -11.9F, -3.9F, 0.1F, -11.9F, -3.9F);
    this.rightArmModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightArmModel[1].addShapeBox(-3.55F, 1.0F, -1.5F, 1, 2, 3, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.rightArmModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
