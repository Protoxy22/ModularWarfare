package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelGasMask
  extends ModelArmor
{
  int textureX = 64;
  int textureY = 64;
  
  public ModelGasMask()
  {
    this.headModel = new ModelRendererTurbo[32];
    this.headModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    this.headModel[1] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    this.headModel[2] = new ModelRendererTurbo(this, 41, 1, this.textureX, this.textureY);
    this.headModel[3] = new ModelRendererTurbo(this, 1, 9, this.textureX, this.textureY);
    this.headModel[4] = new ModelRendererTurbo(this, 18, 9, this.textureX, this.textureY);
    this.headModel[5] = new ModelRendererTurbo(this, 57, 1, this.textureX, this.textureY);
    this.headModel[6] = new ModelRendererTurbo(this, 41, 9, this.textureX, this.textureY);
    this.headModel[7] = new ModelRendererTurbo(this, 49, 9, this.textureX, this.textureY);
    this.headModel[8] = new ModelRendererTurbo(this, 57, 9, this.textureX, this.textureY);
    this.headModel[9] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.headModel[10] = new ModelRendererTurbo(this, 9, 17, this.textureX, this.textureY);
    this.headModel[11] = new ModelRendererTurbo(this, 41, 17, this.textureX, this.textureY);
    this.headModel[12] = new ModelRendererTurbo(this, 49, 17, this.textureX, this.textureY);
    this.headModel[13] = new ModelRendererTurbo(this, 57, 17, this.textureX, this.textureY);
    this.headModel[14] = new ModelRendererTurbo(this, 1, 25, this.textureX, this.textureY);
    this.headModel[15] = new ModelRendererTurbo(this, 9, 25, this.textureX, this.textureY);
    this.headModel[16] = new ModelRendererTurbo(this, 17, 25, this.textureX, this.textureY);
    this.headModel[17] = new ModelRendererTurbo(this, 25, 25, this.textureX, this.textureY);
    this.headModel[18] = new ModelRendererTurbo(this, 33, 25, this.textureX, this.textureY);
    this.headModel[19] = new ModelRendererTurbo(this, 41, 25, this.textureX, this.textureY);
    this.headModel[20] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.headModel[21] = new ModelRendererTurbo(this, 33, 33, this.textureX, this.textureY);
    this.headModel[22] = new ModelRendererTurbo(this, 49, 25, this.textureX, this.textureY);
    this.headModel[23] = new ModelRendererTurbo(this, 1, 49, this.textureX, this.textureY);
    this.headModel[24] = new ModelRendererTurbo(this, 25, 49, this.textureX, this.textureY);
    this.headModel[25] = new ModelRendererTurbo(this, 25, 33, this.textureX, this.textureY);
    this.headModel[26] = new ModelRendererTurbo(this, 1, 33, this.textureX, this.textureY);
    this.headModel[27] = new ModelRendererTurbo(this, 57, 33, this.textureX, this.textureY);
    this.headModel[28] = new ModelRendererTurbo(this, 49, 49, this.textureX, this.textureY);
    this.headModel[29] = new ModelRendererTurbo(this, 57, 49, this.textureX, this.textureY);
    this.headModel[30] = new ModelRendererTurbo(this, 1, 57, this.textureX, this.textureY);
    this.headModel[31] = new ModelRendererTurbo(this, 9, 57, this.textureX, this.textureY);
    
    this.headModel[0].addShapeBox(-4.0F, -8.0F, -4.0F, 8, 4, 2, 0.0F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 1.1F, 0.1F, 0.1F, 1.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F);
    this.headModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[1].addShapeBox(-1.5F, -3.0F, -7.0F, 3, 1, 3, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[2].addShapeBox(-1.5F, -1.0F, -7.0F, 3, 1, 3, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F);
    this.headModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[3].addShapeBox(-1.5F, -2.0F, -7.0F, 3, 1, 3, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[4].addShapeBox(-4.0F, -8.0F, -5.0F, 8, 8, 1, 0.0F, -1.0F, -2.0F, -0.1F, -1.0F, -2.0F, -0.1F, 0.1F, 0.1F, -0.1F, 0.1F, 0.1F, -0.1F, -2.0F, -1.0F, 1.0F, -2.0F, -1.0F, 1.0F, 0.1F, 0.1F, -0.1F, 0.1F, 0.1F, -0.1F);
    this.headModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[5].addShapeBox(1.0F, -5.6F, -5.5F, 2, 1, 1, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F);
    this.headModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[6].addShapeBox(1.0F, -6.5F, -5.5F, 2, 1, 1, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F);
    this.headModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[7].addShapeBox(1.0F, -4.7F, -5.5F, 2, 1, 1, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F);
    this.headModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[8].addShapeBox(-3.0F, -4.7F, -5.5F, 2, 1, 1, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F);
    this.headModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[9].addShapeBox(-3.0F, -5.6F, -5.5F, 2, 1, 1, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F);
    this.headModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[10].addShapeBox(-3.0F, -6.5F, -5.5F, 2, 1, 1, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F);
    this.headModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[11].addShapeBox(-1.0F, -1.1F, -7.3F, 2, 1, 1, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F);
    this.headModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[12].addShapeBox(-1.0F, -2.0F, -7.3F, 2, 1, 1, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F, 0.3F, -0.1F, 0.0F);
    this.headModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[13].addShapeBox(-1.0F, -2.9F, -7.3F, 2, 1, 1, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, -0.5F, -0.2F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F);
    this.headModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[14].addShapeBox(-3.0F, -6.5F, -5.7F, 2, 1, 1, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F);
    this.headModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[15].addShapeBox(-3.0F, -5.6F, -5.7F, 2, 1, 1, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F);
    this.headModel[15].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[16].addShapeBox(-3.0F, -4.7F, -5.7F, 2, 1, 1, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F);
    this.headModel[16].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[17].addShapeBox(1.0F, -4.7F, -5.7F, 2, 1, 1, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F);
    this.headModel[17].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[18].addShapeBox(1.0F, -5.6F, -5.7F, 2, 1, 1, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F, 0.1F, -0.1F, 0.0F);
    this.headModel[18].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[19].addShapeBox(1.0F, -6.5F, -5.7F, 2, 1, 1, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, -0.6F, -0.4F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F);
    this.headModel[19].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[20].addShapeBox(-4.0F, -7.0F, -3.0F, 8, 1, 7, 0.0F, 0.2F, 0.0F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, -0.5F, 0.1F, 0.2F, -0.5F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, 0.5F, 0.1F, 0.2F, 0.5F, 0.1F);
    this.headModel[20].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[21].addShapeBox(-4.0F, -3.0F, -3.0F, 8, 1, 7, 0.0F, 0.2F, 0.0F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, 1.0F, 0.1F, 0.2F, 1.0F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, 0.0F, 0.1F, 0.2F, -1.0F, 0.1F, 0.2F, -1.0F, 0.1F);
    this.headModel[21].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[22].addShapeBox(-1.5F, -6.25F, 3.1F, 3, 3, 1, 0.0F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F, 0.2F);
    this.headModel[22].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[23].addShapeBox(-4.0F, -7.0F, -3.0F, 8, 1, 1, 0.0F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F);
    this.headModel[23].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[24].addShapeBox(-4.0F, -3.0F, -3.0F, 8, 1, 1, 0.0F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F, 0.3F, -0.1F, -0.1F);
    this.headModel[24].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[25].addBox(0.0F, -1.2F, -6.45F, 3, 1, 1, 0.0F);
    this.headModel[25].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[26].addShapeBox(2.3F, -1.2F, -6.45F, 2, 1, 1, 0.0F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F, 0.0F, -0.2F, 0.2F);
    this.headModel[26].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[27].addShapeBox(2.3F, -1.4F, -6.45F, 2, 1, 1, 0.0F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F);
    this.headModel[27].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[28].addShapeBox(2.3F, -1.0F, -6.45F, 2, 1, 1, 0.0F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F, 0.0F, -0.6F, 0.2F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, -0.1F);
    this.headModel[28].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[29].addShapeBox(-0.5F, -6.25F, 3.2F, 1, 3, 1, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F);
    this.headModel[29].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[30].addShapeBox(-0.5F, -4.3F, -6.0F, 1, 1, 1, 0.0F, -0.2F, 0.2F, -0.6F, -0.2F, 0.2F, -0.6F, 0.3F, 0.6F, 0.0F, 0.3F, 0.6F, 0.0F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    this.headModel[30].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[31].addShapeBox(-4.0F, -4.0F, -4.0F, 8, 4, 2, 0.0F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.0F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 1.1F, 0.1F, 0.1F, 1.1F);
    this.headModel[31].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
