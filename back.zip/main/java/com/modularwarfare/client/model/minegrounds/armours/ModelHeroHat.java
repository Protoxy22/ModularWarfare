package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;
public class ModelHeroHat
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelHeroHat()
  {
    this.headModel = new ModelRendererTurbo[3];
    this.headModel[0] = new ModelRendererTurbo(this, 17, 17, this.textureX, this.textureY);
    this.headModel[1] = new ModelRendererTurbo(this, 41, 33, this.textureX, this.textureY);
    this.headModel[2] = new ModelRendererTurbo(this, 81, 33, this.textureX, this.textureY);
    
    this.headModel[0].addShapeBox(-4.0F, -5.25F, -7.0F, 8, 1, 3, 0.0F, 0.1F, -0.8F, 0.0F, 0.1F, -0.8F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, 0.0F, 0.0F, 0.1F, -0.2F, 0.0F, 0.1F, -0.2F, 0.0F, 0.1F, -0.8F, 0.0F, 0.1F, -0.8F, 0.0F);
    this.headModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[1].addShapeBox(-4.0F, -8.0F, -4.0F, 8, 3, 8, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F, 0.2F, 0.2F, 0.0F, 0.2F, 0.2F, 0.5F, 0.2F, 0.2F, 0.5F, 0.2F);
    this.headModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[2].addShapeBox(-4.0F, -8.8F, -4.0F, 8, 1, 8, 0.0F, -1.0F, -0.2F, -1.0F, -1.0F, -0.2F, -1.0F, -1.0F, -0.2F, -1.0F, -1.0F, -0.2F, -1.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F, 0.0F, -0.2F, 0.0F);
    this.headModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
