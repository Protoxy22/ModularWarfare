package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelBanditBoots extends ModelArmor {
  int textureX = 128;
  int textureY = 128;
  
  public ModelBanditBoots()
  {
    this.leftLegModel = new ModelRendererTurbo[1];
    this.leftLegModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
    
    this.leftLegModel[0].addShapeBox(-2.0F, 7.1F, -2.3F, 4, 5, 5, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F);
    this.leftLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel = new ModelRendererTurbo[1];
    this.rightLegModel[0] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    
    this.rightLegModel[0].addShapeBox(-2.0F, 7.1F, -2.3F, 4, 5, 5, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 0.4F, 0.0F, -0.4F, 0.4F, 0.0F, -0.4F);
    this.rightLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
