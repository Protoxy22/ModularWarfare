package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelkskBoots
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelkskBoots()
  {
    this.leftLegModel = new ModelRendererTurbo[1];
    this.leftLegModel[0] = new ModelRendererTurbo(this, 89, 97, this.textureX, this.textureY);
    
    this.leftLegModel[0].addShapeBox(-2.5F, 9.0F, -3.0F, 5, 3, 6, 0.0F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F);
    this.leftLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.rightLegModel = new ModelRendererTurbo[1];
    this.rightLegModel[0] = new ModelRendererTurbo(this, 65, 97, this.textureX, this.textureY);
    
    this.rightLegModel[0].addShapeBox(-2.5F, 9.0F, -3.0F, 5, 3, 6, 0.0F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 1.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F);
    this.rightLegModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
