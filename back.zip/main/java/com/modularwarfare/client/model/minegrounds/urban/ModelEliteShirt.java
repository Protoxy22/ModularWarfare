package com.modularwarfare.client.model.minegrounds.urban;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelEliteShirt extends ModelArmor {

    int textureX = 512;
    int textureY = 512;

    public ModelEliteShirt() {
        bodyModel = new ModelRendererTurbo[1];
        bodyModel[0] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 0

        bodyModel[0].addShapeBox(-4F, 0F, -2F, 8, 12, 4, 0F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F); // Box 0
        bodyModel[0].setRotationPoint(0F, 0F, 0F);


        leftArmModel = new ModelRendererTurbo[1];
        leftArmModel[0] = new ModelRendererTurbo(this, 57, 1, textureX, textureY); // Box 2

        leftArmModel[0].addShapeBox(-1F, -2F, -2F, 4, 4, 4, 0F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F); // Box 2
        leftArmModel[0].setRotationPoint(0F, 0F, 0F);


        rightArmModel = new ModelRendererTurbo[1];
        rightArmModel[0] = new ModelRendererTurbo(this, 33, 1, textureX, textureY); // Box 1

        rightArmModel[0].addShapeBox(-3F, -2F, -2F, 4, 4, 4, 0F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F, 0.1F, 0F, 0.1F); // Box 1
        rightArmModel[0].setRotationPoint(0F, 0F, 0F);


    }
}