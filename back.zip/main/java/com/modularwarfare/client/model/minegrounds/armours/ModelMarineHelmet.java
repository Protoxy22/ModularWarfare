package com.modularwarfare.client.model.minegrounds.armours;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class ModelMarineHelmet
  extends ModelArmor
{
  int textureX = 128;
  int textureY = 128;
  
  public ModelMarineHelmet()
  {
    this.headModel = new ModelRendererTurbo[22];
    this.headModel[0] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
    this.headModel[1] = new ModelRendererTurbo(this, 81, 9, this.textureX, this.textureY);
    this.headModel[2] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
    this.headModel[3] = new ModelRendererTurbo(this, 81, 1, this.textureX, this.textureY);
    this.headModel[4] = new ModelRendererTurbo(this, 89, 1, this.textureX, this.textureY);
    this.headModel[5] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
    this.headModel[6] = new ModelRendererTurbo(this, 105, 1, this.textureX, this.textureY);
    this.headModel[7] = new ModelRendererTurbo(this, 113, 1, this.textureX, this.textureY);
    this.headModel[8] = new ModelRendererTurbo(this, 1, 17, this.textureX, this.textureY);
    this.headModel[9] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
    this.headModel[10] = new ModelRendererTurbo(this, 25, 17, this.textureX, this.textureY);
    this.headModel[11] = new ModelRendererTurbo(this, 33, 17, this.textureX, this.textureY);
    this.headModel[12] = new ModelRendererTurbo(this, 1, 25, this.textureX, this.textureY);
    this.headModel[13] = new ModelRendererTurbo(this, 73, 49, this.textureX, this.textureY);
    this.headModel[14] = new ModelRendererTurbo(this, 49, 65, this.textureX, this.textureY);
    this.headModel[15] = new ModelRendererTurbo(this, 65, 65, this.textureX, this.textureY);
    this.headModel[16] = new ModelRendererTurbo(this, 89, 25, this.textureX, this.textureY);
    this.headModel[17] = new ModelRendererTurbo(this, 41, 33, this.textureX, this.textureY);
    this.headModel[18] = new ModelRendererTurbo(this, 25, 25, this.textureX, this.textureY);
    this.headModel[19] = new ModelRendererTurbo(this, 113, 25, this.textureX, this.textureY);
    this.headModel[20] = new ModelRendererTurbo(this, 65, 33, this.textureX, this.textureY);
    this.headModel[21] = new ModelRendererTurbo(this, 121, 41, this.textureX, this.textureY);
    
    this.headModel[0].addShapeBox(-5.0F, -7.0F, -5.0F, 10, 3, 10, 0.0F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, 0.0F, -0.5F, -0.4F, 0.0F, -0.5F, -0.4F, 0.0F, -0.5F, 0.0F, 0.0F, -0.5F, 0.0F);
    this.headModel[0].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[1].addShapeBox(-5.0F, -9.0F, -5.0F, 10, 2, 10, 0.0F, -1.5F, 0.0F, -1.5F, -1.5F, 0.0F, -1.5F, -1.5F, 0.0F, -1.5F, -1.5F, 0.0F, -1.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F, -0.5F, 0.0F, -0.5F);
    this.headModel[1].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[2].addShapeBox(-5.0F, -4.5F, -4.0F, 1, 1, 2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, -0.3F, -2.0F, -0.25F, -0.3F, -2.0F, -0.25F, -0.3F, 0.0F, 0.25F, -0.3F, 0.0F);
    this.headModel[2].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[3].addShapeBox(-5.5F, -4.5F, -2.0F, 1, 2, 2, 0.0F, -0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.25F, -1.3F, 0.0F, 0.25F, -1.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F);
    this.headModel[3].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[4].addShapeBox(-5.0F, -4.5F, 0.0F, 1, 2, 5, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 0.3F, 0.0F, -0.5F, 0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.headModel[4].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[5].addShapeBox(4.0F, -4.5F, -4.0F, 1, 1, 2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.25F, -0.3F, -2.0F, 0.25F, -0.3F, -2.0F, 0.25F, -0.3F, 0.0F, -0.25F, -0.3F, 0.0F);
    this.headModel[5].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[6].addShapeBox(3.5F, -4.5F, -2.0F, 1, 2, 2, 0.0F, -0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.5F, 0.0F, 0.0F, -0.75F, -1.3F, 0.0F, 0.75F, -1.3F, 0.0F, 1.0F, 0.3F, 0.0F, -1.0F, 0.3F, 0.0F);
    this.headModel[6].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[7].addShapeBox(4.0F, -4.5F, 0.0F, 1, 2, 5, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5F, 0.3F, 0.0F, 0.5F, 0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.headModel[7].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[8].addShapeBox(-4.0F, -4.5F, 4.0F, 8, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[8].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[9].addShapeBox(-4.0F, -3.5F, 4.0F, 4, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.7F, 0.0F, 0.0F, -0.7F, 0.0F, 0.0F, -0.3F, 0.0F);
    this.headModel[9].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[10].addShapeBox(0.0F, -3.5F, 4.0F, 4, 1, 1, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, -0.7F, 0.0F);
    this.headModel[10].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[11].addShapeBox(-5.0F, -6.0F, -5.0F, 10, 1, 10, 0.0F, -0.3F, 0.0F, -0.4F, -0.3F, 0.0F, -0.4F, -0.2F, -0.2F, -0.2F, -0.2F, -0.2F, -0.2F, -0.2F, -0.5F, -0.4F, -0.2F, -0.5F, -0.4F, -0.1F, -0.2F, -0.1F, -0.1F, -0.2F, -0.1F);
    this.headModel[11].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[12].addShapeBox(-4.5F, -4.0F, -4.5F, 9, 4, 4, 0.0F, 0.0F, 0.0F, -3.0F, 0.0F, 0.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.4F, 0.0F, -0.5F, -0.4F, 0.0F, -0.5F, -0.4F, 0.0F, -2.5F, -0.4F, 0.0F, -2.5F);
    this.headModel[12].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[13].addShapeBox(-4.5F, 0.0F, -4.0F, 9, 1, 1, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.6F, -0.8F, 0.0F, -0.6F, -0.8F, 0.0F, -0.6F, -0.8F, 0.0F, -0.6F, -0.8F, 0.0F);
    this.headModel[13].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[14].addShapeBox(-5.0F, -5.5F, -5.6F, 10, 1, 1, 0.0F, -0.1F, -0.5F, -1.02F, -0.1F, -0.5F, -1.02F, -0.1F, -0.5F, 0.02F, -0.1F, -0.5F, 0.02F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, -0.4F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[14].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[15].addShapeBox(-5.0F, -7.2F, -5.0F, 10, 1, 10, 0.0F, -0.4F, 0.0F, -0.5F, -0.4F, 0.0F, -0.5F, -0.4F, -0.2F, -0.4F, -0.4F, -0.2F, -0.4F, -0.2F, 0.0F, -0.4F, -0.2F, 0.0F, -0.4F, -0.1F, 0.2F, -0.1F, -0.1F, 0.2F, -0.1F);
    this.headModel[15].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[16].addShapeBox(1.0F, -7.75F, -5.3F, 3, 2, 1, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.0F, -0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F);
    this.headModel[16].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[17].addShapeBox(-4.0F, -7.75F, -5.3F, 3, 2, 1, 0.0F, 0.0F, 0.0F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.0F, 0.0F);
    this.headModel[17].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[18].addShapeBox(-1.0F, -7.75F, -5.3F, 2, 2, 1, 0.0F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, -0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.3F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 0.3F, 0.0F);
    this.headModel[18].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[19].addShapeBox(-1.0F, -5.5F, -5.6F, 2, 1, 1, 0.0F, -0.35F, 0.2F, 0.0F, -0.35F, 0.2F, 0.0F, -0.35F, 0.0F, 0.0F, -0.35F, 0.0F, 0.0F, -0.35F, -0.6F, 0.0F, -0.35F, -0.6F, 0.0F, -0.35F, -0.25F, 0.0F, -0.35F, -0.25F, 0.0F);
    this.headModel[19].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[20].addShapeBox(-1.0F, -7.0F, -5.6F, 2, 1, 1, 0.0F, -0.35F, 0.0F, -0.3F, -0.35F, 0.0F, -0.3F, -0.35F, 0.0F, -0.5F, -0.35F, 0.0F, -0.5F, -0.35F, 0.3F, 0.0F, -0.35F, 0.3F, 0.0F, -0.35F, 0.35F, -0.8F, -0.35F, 0.35F, -0.8F);
    this.headModel[20].setRotationPoint(0.0F, 0.0F, 0.0F);
    
    this.headModel[21].addShapeBox(-1.0F, -8.2F, -5.6F, 2, 1, 1, 0.0F, -0.35F, 0.2F, -0.5F, -0.35F, 0.2F, -0.5F, -0.35F, 0.0F, 0.0F, -0.35F, 0.0F, 0.0F, -0.35F, 0.2F, 0.2F, -0.35F, 0.2F, 0.2F, -0.35F, 0.5F, -0.6F, -0.35F, 0.5F, -0.6F);
    this.headModel[21].setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}
