package com.modularwarfare.client.model.minegrounds.urban;

import com.modularwarfare.client.model.ModelArmor;
import com.modularwarfare.client.tmt.ModelRendererTurbo;

public class Modeltm4o extends ModelArmor
{
    int textureX;
    int textureY;
    
    public Modeltm4o() {
        this.textureX = 512;
        this.textureY = 512;
        this.bodyModel = new ModelRendererTurbo[21];
        this.leftArmModel = new ModelRendererTurbo[12];
        this.rightArmModel = new ModelRendererTurbo[12];
        this.initbodyModel_1();
        this.initleftArmModel_1();
        this.initrightArmModel_1();
    }

    private void initbodyModel_1() {
        this.bodyModel[0] = new ModelRendererTurbo(this, 4, 62, this.textureX, this.textureY);
        this.bodyModel[1] = new ModelRendererTurbo(this, 24, 59, this.textureX, this.textureY);
        this.bodyModel[2] = new ModelRendererTurbo(this, 25, 56, this.textureX, this.textureY);
        this.bodyModel[3] = new ModelRendererTurbo(this, 27, 62, this.textureX, this.textureY);
        this.bodyModel[4] = new ModelRendererTurbo(this, 25, 53, this.textureX, this.textureY);
        this.bodyModel[5] = new ModelRendererTurbo(this, 5, 54, this.textureX, this.textureY);
        this.bodyModel[6] = new ModelRendererTurbo(this, 73, 52, this.textureX, this.textureY);
        this.bodyModel[7] = new ModelRendererTurbo(this, 66, 55, this.textureX, this.textureY);
        this.bodyModel[8] = new ModelRendererTurbo(this, 59, 55, this.textureX, this.textureY);
        this.bodyModel[9] = new ModelRendererTurbo(this, 63, 53, this.textureX, this.textureY);
        this.bodyModel[10] = new ModelRendererTurbo(this, 68, 64, this.textureX, this.textureY);
        this.bodyModel[11] = new ModelRendererTurbo(this, 62, 56, this.textureX, this.textureY);
        this.bodyModel[12] = new ModelRendererTurbo(this, 63, 64, this.textureX, this.textureY);
        this.bodyModel[13] = new ModelRendererTurbo(this, 76, 61, this.textureX, this.textureY);
        this.bodyModel[14] = new ModelRendererTurbo(this, 72, 57, this.textureX, this.textureY);
        this.bodyModel[15] = new ModelRendererTurbo(this, 63, 68, this.textureX, this.textureY);
        this.bodyModel[16] = new ModelRendererTurbo(this, 61, 60, this.textureX, this.textureY);
        this.bodyModel[17] = new ModelRendererTurbo(this, 68, 60, this.textureX, this.textureY);
        this.bodyModel[18] = new ModelRendererTurbo(this, 76, 65, this.textureX, this.textureY);
        this.bodyModel[19] = new ModelRendererTurbo(this, 68, 68, this.textureX, this.textureY);
        this.bodyModel[20] = new ModelRendererTurbo(this, 59, 51, this.textureX, this.textureY);
        this.bodyModel[0].addShapeBox(-4.0f, 1.0f, -2.0f, 8, 11, 4, 0.0f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f);
        this.bodyModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[1].addShapeBox(-4.0f, 0.0f, -2.0f, 2, 1, 1, 0.0f, 0.1f, 0.2f, 0.3f, -0.3f, 0.2f, 0.3f, -0.3f, 0.2f, 0.2f, 0.1f, 0.2f, 0.2f, 0.1f, -0.5f, 0.3f, 0.2f, -0.5f, 0.3f, 0.2f, -0.5f, 0.2f, 0.1f, -0.5f, 0.2f);
        this.bodyModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[2].addShapeBox(-4.0f, 0.0f, -2.0f, 2, 1, 1, 0.0f, 0.1f, -0.5f, 0.3f, 0.2f, -0.5f, 0.3f, 0.2f, -0.5f, 0.2f, 0.1f, -0.5f, 0.2f, 0.1f, 0.0f, 0.3f, 1.2f, 0.0f, 0.3f, 1.2f, 0.0f, 0.2f, 0.1f, 0.0f, 0.2f);
        this.bodyModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[3].addShapeBox(2.0f, 0.0f, -2.0f, 2, 1, 1, 0.0f, 0.2f, -0.5f, 0.3f, 0.1f, -0.5f, 0.3f, 0.1f, -0.5f, 0.2f, 0.2f, -0.5f, 0.2f, 1.2f, 0.0f, 0.3f, 0.1f, 0.0f, 0.3f, 0.1f, 0.0f, 0.2f, 1.2f, 0.0f, 0.2f);
        this.bodyModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[4].addShapeBox(2.0f, 0.0f, -2.0f, 2, 1, 1, 0.0f, -0.3f, 0.2f, 0.3f, 0.1f, 0.2f, 0.3f, 0.1f, 0.2f, 0.2f, -0.3f, 0.2f, 0.2f, 0.2f, -0.5f, 0.3f, 0.1f, -0.5f, 0.3f, 0.1f, -0.5f, 0.2f, 0.2f, -0.5f, 0.2f);
        this.bodyModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[5].addShapeBox(-3.0f, 0.0f, -1.0f, 7, 1, 3, 0.0f, 1.1f, 0.2f, -0.2f, 0.1f, 0.2f, -0.2f, 0.1f, 0.2f, 0.3f, 1.1f, 0.2f, 0.3f, 1.1f, 0.0f, -0.2f, 0.1f, 0.0f, -0.2f, 0.1f, 0.0f, 0.3f, 1.1f, 0.0f, 0.3f);
        this.bodyModel[5].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[6].addShapeBox(-3.0f, 0.0f, -2.0f, 1, 1, 2, 0.0f, -0.4f, 0.3f, 0.3f, -0.1f, 0.3f, 0.3f, -0.1f, 0.3f, 0.0f, -0.4f, 0.3f, 0.0f, -0.4f, -1.1f, 0.4f, -0.1f, -1.1f, 0.4f, -0.1f, -1.1f, 0.0f, -0.4f, -1.1f, 0.0f);
        this.bodyModel[6].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[7].addShapeBox(-3.0f, 0.0f, -2.0f, 1, 1, 1, 0.0f, -0.4f, 0.1f, 0.4f, -0.1f, 0.1f, 0.4f, -0.1f, 0.1f, -1.2f, -0.4f, 0.1f, -1.2f, -0.9f, -0.5f, 0.4f, 0.4f, -0.5f, 0.4f, 0.4f, -0.5f, -1.2f, -0.9f, -0.5f, -1.2f);
        this.bodyModel[7].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[8].addShapeBox(-3.0f, 0.0f, -2.0f, 1, 1, 1, 0.0f, -0.9f, -0.5f, 0.4f, 0.4f, -0.5f, 0.4f, 0.4f, -0.5f, -1.2f, -0.9f, -0.5f, -1.2f, -2.2f, -8.326673E-17f, 0.4f, 1.5f, -0.2f, 0.4f, 1.5f, -0.2f, -1.2f, -2.2f, -8.326673E-17f, -1.2f);
        this.bodyModel[8].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[9].addShapeBox(2.0f, 0.0f, -2.0f, 1, 1, 1, 0.0f, 0.4f, -0.5f, 0.4f, -0.9f, -0.5f, 0.4f, -0.9f, -0.5f, -1.2f, 0.4f, -0.5f, -1.2f, 1.5f, -0.2f, 0.4f, -2.2f, -8.326673E-17f, 0.4f, -2.2f, -8.326673E-17f, -1.2f, 1.5f, -0.2f, -1.2f);
        this.bodyModel[9].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[10].addShapeBox(2.0f, 0.0f, -2.0f, 1, 1, 1, 0.0f, -0.1f, 0.1f, 0.4f, -0.4f, 0.1f, 0.4f, -0.4f, 0.1f, -1.2f, -0.1f, 0.1f, -1.2f, 0.4f, -0.5f, 0.4f, -0.9f, -0.5f, 0.4f, -0.9f, -0.5f, -1.2f, 0.4f, -0.5f, -1.2f);
        this.bodyModel[10].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[11].addShapeBox(2.0f, 0.0f, -2.0f, 1, 1, 2, 0.0f, -0.1f, 0.3f, 0.3f, -0.4f, 0.3f, 0.3f, -0.4f, 0.3f, 0.0f, -0.1f, 0.3f, 0.0f, -0.1f, -1.1f, 0.4f, -0.4f, -1.1f, 0.4f, -0.4f, -1.1f, 0.0f, -0.1f, -1.1f, 0.0f);
        this.bodyModel[11].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[12].addShapeBox(2.0f, -0.1f, -2.0f, 1, 1, 1, 0.0f, 2.5f, -0.9f, 0.4f, -3.0f, -1.0f, 0.4f, -3.0f, -1.0f, -1.2f, 2.5f, -0.9f, -1.2f, 2.8f, 0.1f, 0.4f, -3.0f, 0.3f, 0.4f, -3.0f, 0.3f, -1.2f, 2.8f, 0.1f, -1.2f);
        this.bodyModel[12].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[13].addShapeBox(-3.0f, -0.1f, -2.0f, 1, 1, 1, 0.0f, -3.0f, -1.0f, 0.4f, 2.5f, -0.9f, 0.4f, 2.5f, -0.9f, -1.2f, -3.0f, -1.0f, -1.2f, -3.0f, 0.3f, 0.4f, 2.8f, 0.1f, 0.4f, 2.8f, 0.1f, -1.2f, -3.0f, 0.3f, -1.2f);
        this.bodyModel[13].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[14].addShapeBox(2.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, -0.1f, 0.3f, -5.551115E-17f, -0.4f, 0.3f, -2.7755576E-17f, -0.9f, 0.3f, 0.0f, 0.3f, 0.3f, -0.3f, -0.1f, -1.1f, -5.551115E-17f, -0.4f, -1.1f, -2.7755576E-17f, -0.9f, -1.1f, 0.0f, 0.3f, -1.1f, -0.3f);
        this.bodyModel[14].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[15].addShapeBox(-3.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, -0.9f, 0.3f, -1.0f, 0.3f, 0.3f, -0.7f, 0.8f, 0.3f, 2.7755576E-17f, -1.7f, 0.3f, 0.5f, -0.9f, -1.1f, -1.0f, 0.3f, -1.1f, -0.7f, 0.8f, -1.1f, 2.7755576E-17f, -1.7f, -1.1f, 0.5f);
        this.bodyModel[15].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[16].addShapeBox(-3.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, -0.4f, 0.3f, -2.7755576E-17f, -0.1f, 0.3f, -5.551115E-17f, 0.3f, 0.3f, -0.3f, -0.9f, 0.3f, 0.0f, -0.4f, -1.1f, -2.7755576E-17f, -0.1f, -1.1f, -5.551115E-17f, 0.3f, -1.1f, -0.3f, -0.9f, -1.1f, 0.0f);
        this.bodyModel[16].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[17].addShapeBox(2.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, 0.3f, 0.3f, -0.7f, -0.9f, 0.3f, -1.0f, -1.7f, 0.3f, 0.5f, 0.8f, 0.3f, 2.7755576E-17f, 0.3f, -1.1f, -0.7f, -0.9f, -1.1f, -1.0f, -1.7f, -1.1f, 0.5f, 0.8f, -1.1f, 2.7755576E-17f);
        this.bodyModel[17].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[18].addShapeBox(-3.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, -1.8f, 0.3f, -1.0f, 1.9f, 0.3f, -1.2f, 1.9f, 0.3f, 0.7f, -1.7f, 0.3f, 0.5f, -1.8f, -1.1f, -1.0f, 1.9f, -1.1f, -1.2f, 1.9f, -1.1f, 0.7f, -1.7f, -1.1f, 0.5f);
        this.bodyModel[18].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[19].addShapeBox(2.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, 1.9f, 0.3f, -1.2f, -1.8f, 0.3f, -1.0f, -1.7f, 0.3f, 0.5f, 1.9f, 0.3f, 0.7f, 1.9f, -1.1f, -1.2f, -1.8f, -1.1f, -1.0f, -1.7f, -1.1f, 0.5f, 1.9f, -1.1f, 0.7f);
        this.bodyModel[19].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bodyModel[20].addShapeBox(2.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f, 2.1f, 0.3f, -1.2f, -2.9f, 0.3f, -1.2f, -2.9f, 0.3f, 0.7f, 2.1f, 0.3f, 0.7f, 2.1f, -1.1f, -1.2f, -2.9f, -1.1f, -1.2f, -2.9f, -1.1f, 0.7f, 2.1f, -1.1f, 0.7f);
        this.bodyModel[20].setRotationPoint(0.0f, 0.0f, 0.0f);
    }

    private void initleftArmModel_1() {
        this.leftArmModel[0] = new ModelRendererTurbo(this, 73, 1, this.textureX, this.textureY);
        this.leftArmModel[1] = new ModelRendererTurbo(this, 97, 1, this.textureX, this.textureY);
        this.leftArmModel[2] = new ModelRendererTurbo(this, 121, 1, this.textureX, this.textureY);
        this.leftArmModel[3] = new ModelRendererTurbo(this, 57, 9, this.textureX, this.textureY);
        this.leftArmModel[4] = new ModelRendererTurbo(this, 73, 9, this.textureX, this.textureY);
        this.leftArmModel[5] = new ModelRendererTurbo(this, 89, 9, this.textureX, this.textureY);
        this.leftArmModel[6] = new ModelRendererTurbo(this, 113, 9, this.textureX, this.textureY);
        this.leftArmModel[7] = new ModelRendererTurbo(this, 129, 9, this.textureX, this.textureY);
        this.leftArmModel[8] = new ModelRendererTurbo(this, 169, 9, this.textureX, this.textureY);
        this.leftArmModel[9] = new ModelRendererTurbo(this, 201, 9, this.textureX, this.textureY);
        this.leftArmModel[10] = new ModelRendererTurbo(this, 241, 9, this.textureX, this.textureY);
        this.leftArmModel[11] = new ModelRendererTurbo(this, 257, 9, this.textureX, this.textureY);
        this.leftArmModel[0].addShapeBox(-1.0f, -2.0f, -2.0f, 4, 3, 4, 0.0f, 0.3f, 0.2f, 0.3f, 0.3f, 0.1f, 0.3f, 0.3f, 0.1f, 0.3f, 0.3f, 0.2f, 0.3f, 0.3f, 0.0f, 0.3f, 0.3f, 0.5f, 0.3f, 0.3f, 0.5f, 0.3f, 0.3f, 0.0f, 0.3f);
        this.leftArmModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[1].addShapeBox(-1.0f, 1.0f, -2.0f, 4, 6, 4, 0.0f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f);
        this.leftArmModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[2].addShapeBox(-1.0f, 7.0f, -2.0f, 4, 3, 4, 0.0f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        this.leftArmModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[3].addShapeBox(2.0f, -2.0f, -2.0f, 1, 1, 4, 0.0f, 0.3f, 0.2f, 0.4f, 0.4f, 0.2f, 0.4f, 0.4f, 0.2f, 0.4f, 0.3f, 0.2f, 0.4f, 0.5f, -0.4f, 0.4f, 0.5f, -0.6f, 0.4f, 0.5f, -0.6f, 0.4f, 0.5f, -0.4f, 0.4f);
        this.leftArmModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[4].addShapeBox(0.0f, -2.0f, -2.0f, 1, 1, 4, 0.0f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.7f, -0.6f, 0.5f, 0.5f, -0.3f, 0.5f, 0.5f, -0.3f, 0.5f, 0.7f, -0.6f, 0.5f);
        this.leftArmModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[5].addShapeBox(0.0f, -2.0f, -2.5f, 1, 1, 5, 0.0f, 1.0f, 0.2f, -0.2f, -1.7f, 0.2f, 0.0f, -1.7f, 0.2f, 0.0f, 1.0f, 0.2f, -0.2f, 0.9f, -0.7f, -0.1f, -1.7f, -0.6f, 0.0f, -1.7f, -0.6f, 0.0f, 0.9f, -0.7f, -0.1f);
        this.leftArmModel[5].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[6].addShapeBox(-0.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, 0.4f, -0.6f, 0.3f, -1.2f, -0.4f, 0.3f, -1.2f, -0.4f, 0.3f, 0.4f, -0.6f, 0.3f, 0.5f, -0.2f, 0.3f, -1.2f, -0.2f, 0.5f, -1.2f, -0.2f, 0.5f, 0.5f, -0.2f, 0.3f);
        this.leftArmModel[6].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[7].addShapeBox(-0.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, 0.2f, -0.4f, 0.3f, -0.5f, -0.1f, 0.2f, -0.5f, -0.1f, 0.3f, 0.2f, -0.4f, 0.3f, 0.2f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f);
        this.leftArmModel[7].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[8].addShapeBox(-1.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -1.0f, -0.1f, 0.2f, 1.0f, -0.1f, 0.1f, 1.0f, -0.1f, 0.2f, -1.0f, -0.1f, 0.3f, -1.0f, -0.2f, 0.5f, 1.0f, -0.2f, 0.5f, 1.0f, -0.2f, 0.5f, -1.0f, -0.2f, 0.5f);
        this.leftArmModel[8].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[9].addShapeBox(0.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -0.5f, -0.1f, 0.1f, -1.6653345E-16f, -0.2f, 9.436896E-16f, -1.6653345E-16f, -0.2f, -5.551115E-17f, -0.5f, -0.1f, 0.2f, -0.5f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f);
        this.leftArmModel[9].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[10].addShapeBox(1.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -0.2f, -0.4f, 1.110223E-16f, 0.2f, -0.4f, 8.326673E-17f, 0.2f, -0.4f, 8.326673E-17f, -0.2f, -0.4f, 1.110223E-16f, -0.2f, -0.2f, 0.4f, 0.2f, -0.2f, 0.4f, 0.2f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f);
        this.leftArmModel[10].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.leftArmModel[11].addShapeBox(2.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -0.2f, -0.4f, 1.110223E-16f, -0.1f, -0.5f, -1.1f, -0.1f, -0.5f, -1.1f, -0.2f, -0.4f, 1.110223E-16f, -0.2f, -0.2f, 0.4f, 0.4f, -0.2f, 0.4f, 0.4f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f);
        this.leftArmModel[11].setRotationPoint(0.0f, 0.0f, 0.0f);
    }
    
    private void initrightArmModel_1() {
        this.rightArmModel[0] = new ModelRendererTurbo(this, 1, 1, this.textureX, this.textureY);
        this.rightArmModel[1] = new ModelRendererTurbo(this, 25, 1, this.textureX, this.textureY);
        this.rightArmModel[2] = new ModelRendererTurbo(this, 49, 1, this.textureX, this.textureY);
        this.rightArmModel[3] = new ModelRendererTurbo(this, 377, 1, this.textureX, this.textureY);
        this.rightArmModel[4] = new ModelRendererTurbo(this, 441, 1, this.textureX, this.textureY);
        this.rightArmModel[5] = new ModelRendererTurbo(this, 465, 1, this.textureX, this.textureY);
        this.rightArmModel[6] = new ModelRendererTurbo(this, 481, 1, this.textureX, this.textureY);
        this.rightArmModel[7] = new ModelRendererTurbo(this, 497, 1, this.textureX, this.textureY);
        this.rightArmModel[8] = new ModelRendererTurbo(this, 329, 1, this.textureX, this.textureY);
        this.rightArmModel[9] = new ModelRendererTurbo(this, 1, 9, this.textureX, this.textureY);
        this.rightArmModel[10] = new ModelRendererTurbo(this, 17, 9, this.textureX, this.textureY);
        this.rightArmModel[11] = new ModelRendererTurbo(this, 41, 9, this.textureX, this.textureY);
        this.rightArmModel[0].addShapeBox(-3.0f, -2.0f, -2.0f, 4, 3, 4, 0.0f, 0.3f, 0.1f, 0.3f, 0.3f, 0.2f, 0.3f, 0.3f, 0.2f, 0.3f, 0.3f, 0.1f, 0.3f, 0.3f, 0.5f, 0.3f, 0.3f, 0.0f, 0.3f, 0.3f, 0.0f, 0.3f, 0.3f, 0.5f, 0.3f);
        this.rightArmModel[0].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[1].addShapeBox(-3.0f, 1.0f, -2.0f, 4, 6, 4, 0.0f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f, 0.2f, 0.0f, 0.2f);
        this.rightArmModel[1].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[2].addShapeBox(-3.0f, 7.0f, -2.0f, 4, 3, 4, 0.0f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        this.rightArmModel[2].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[3].addShapeBox(-0.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -1.2f, -0.4f, 0.3f, 0.4f, -0.6f, 0.3f, 0.4f, -0.6f, 0.3f, -1.2f, -0.4f, 0.3f, -1.2f, -0.2f, 0.5f, 0.5f, -0.2f, 0.3f, 0.5f, -0.2f, 0.3f, -1.2f, -0.2f, 0.5f);
        this.rightArmModel[3].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[4].addShapeBox(-0.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -0.5f, -0.1f, 0.2f, 0.2f, -0.4f, 0.3f, 0.2f, -0.4f, 0.3f, -0.5f, -0.1f, 0.3f, -0.5f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f);
        this.rightArmModel[4].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[5].addShapeBox(-1.5f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -1.6653345E-16f, -0.2f, 9.436896E-16f, -0.5f, -0.1f, 0.1f, -0.5f, -0.1f, 0.2f, -1.6653345E-16f, -0.2f, -5.551115E-17f, 0.2f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f, -0.5f, -0.2f, 0.5f, 0.2f, -0.2f, 0.5f);
        this.rightArmModel[5].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[6].addShapeBox(0.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, 1.0f, -0.1f, 0.1f, -1.0f, -0.1f, 0.2f, -1.0f, -0.1f, 0.3f, 1.0f, -0.1f, 0.2f, 1.0f, -0.2f, 0.5f, -1.0f, -0.2f, 0.5f, -1.0f, -0.2f, 0.5f, 1.0f, -0.2f, 0.5f);
        this.rightArmModel[6].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[7].addShapeBox(-1.0f, -2.0f, -2.0f, 1, 1, 4, 0.0f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.7f, 0.2f, 0.5f, 0.5f, -0.3f, 0.5f, 0.7f, -0.6f, 0.5f, 0.7f, -0.6f, 0.5f, 0.5f, -0.3f, 0.5f);
        this.rightArmModel[7].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[8].addShapeBox(-1.0f, -2.0f, -2.5f, 1, 1, 5, 0.0f, -1.7f, 0.2f, 0.0f, 1.0f, 0.2f, -0.2f, 1.0f, 0.2f, -0.2f, -1.7f, 0.2f, 0.0f, -1.7f, -0.6f, 0.0f, 0.9f, -0.7f, -0.1f, 0.9f, -0.7f, -0.1f, -1.7f, -0.6f, 0.0f);
        this.rightArmModel[8].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[9].addShapeBox(-3.0f, -2.0f, -2.0f, 1, 1, 4, 0.0f, 0.4f, 0.2f, 0.4f, 0.3f, 0.2f, 0.4f, 0.3f, 0.2f, 0.4f, 0.4f, 0.2f, 0.4f, 0.5f, -0.6f, 0.4f, 0.5f, -0.4f, 0.4f, 0.5f, -0.4f, 0.4f, 0.5f, -0.6f, 0.4f);
        this.rightArmModel[9].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[10].addShapeBox(-3.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, -0.1f, -0.5f, -1.1f, -0.2f, -0.4f, 1.110223E-16f, -0.2f, -0.4f, 1.110223E-16f, -0.1f, -0.5f, -1.1f, 0.4f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f, 0.4f, -0.2f, 0.4f);
        this.rightArmModel[10].setRotationPoint(0.0f, 0.0f, 0.0f);
        this.rightArmModel[11].addShapeBox(-2.0f, -3.0f, -2.0f, 1, 1, 4, 0.0f, 0.2f, -0.4f, 8.326673E-17f, -0.2f, -0.4f, 1.110223E-16f, -0.2f, -0.4f, 1.110223E-16f, 0.2f, -0.4f, 8.326673E-17f, 0.2f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f, -0.2f, -0.2f, 0.4f, 0.2f, -0.2f, 0.4f);
        this.rightArmModel[11].setRotationPoint(0.0f, 0.0f, 0.0f);
    }
}
