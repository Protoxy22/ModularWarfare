package com.modularwarfare.client.model.objects;

public enum CustomItemRenderType
{
	ENTITY,
	EQUIPPED,
	EQUIPPED_FIRST_PERSON,
	INVENTORY,
}
