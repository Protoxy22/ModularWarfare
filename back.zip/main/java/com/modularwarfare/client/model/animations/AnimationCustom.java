package com.modularwarfare.client.model.animations;

import com.modularwarfare.api.WeaponAnimation;

public class AnimationCustom extends WeaponAnimation {

	
	
}
